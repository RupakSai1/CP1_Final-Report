# Business Intelligence Semantic Layers with Metric Definition Consistency

A complete, working full-stack college project demonstrating enterprise **BI Semantic Layer Management**, **SQL Metric Consistency Validation**, **Metadata Governance**, and **Automated Metric Recommendations**.

---

## Technical Stack

- **Frontend**: React 18, Vite, Lucide React Icons, Vanilla CSS (Modern Light BI Aesthetic)
- **Backend**: Python 3.13, FastAPI, SQLAlchemy ORM, Pydantic, Uvicorn
- **Database**: SQLite (`bi_semantic.db`) with automatic table creation & pre-populated sample metrics on startup

---

## Core Features & Capabilities

1. **Semantic Dashboard**: Overview stats for Total Metrics, Approved Metrics, Pending Governance Reviews, and Inconsistent Logic Flags with visual department breakdowns.
2. **Metric Repository**: Full CRUD management of business metrics including metadata attributes (Name, Unique Business Key, Department, Category, Approved SQL Formula, Aggregation Type, Dimensions, Default Filters, Owner, Version, and Status).
3. **SQL Validation Engine**: Interactive validation workspace where users select an approved metric and paste a submitted SQL snippet (e.g. `SUM(order_amount - discount)`). Semantic comparison flags discrepancies (e.g. unapproved discount deductions, wrong aggregations) and displays an instant `INCONSISTENT` or `APPROVED_MATCH` status.
4. **Metric Recommendation Module**: Shows side-by-side comparison between submitted logic and the approved metric standard, providing a copyable standardized SQL statement.
5. **Consistency Auditor Scanner**: Performs repository-wide audit scans to detect duplicate business keys, formula drift across departments, and flagged metrics. Calculates a live **Semantic Governance Health Score**.
6. **Version History & Audit Log**: Records a detailed change log and version bump (v1.0 → v1.1) for every metric formula update, keeping track of author notes, previous formulas, and timestamps.
7. **Search & Multi-Filter**: Real-time multi-dimensional search and filtering by department, status, category, and keyword.

---

## Project Folder Structure

```
BusinessSemantic/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py                # FastAPI app entrypoint & CORS setup
│   │   ├── database.py            # SQLite engine & session configuration
│   │   ├── models.py              # SQLAlchemy ORM Models (Metric, VersionHistory, ValidationLog)
│   │   ├── schemas.py             # Pydantic data validation schemas
│   │   ├── sql_engine.py          # SQL parsing, semantic comparison, and audit engine
│   │   ├── seed_data.py           # Sample metrics pre-population script
│   │   └── routers/
│   │       ├── metrics.py         # Metrics CRUD & version history endpoints
│   │       ├── validation.py      # SQL validation endpoints
│   │       ├── consistency.py     # Repository consistency audit endpoints
│   │       └── analytics.py       # Dashboard statistics endpoint
│   ├── requirements.txt           # Python dependencies
│   ├── run_backend.py             # Launcher script for FastAPI server
│   └── bi_semantic.db             # Auto-generated SQLite Database
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   ├── src/
│   │   ├── main.jsx
│   │   ├── App.jsx
│   │   ├── index.css              # Light UI theme & design system
│   │   ├── api/
│   │   │   └── api.js             # Axios client for backend communication
│   │   ├── components/
│   │   │   ├── Header.jsx         # Top Navigation Header
│   │   │   ├── Sidebar.jsx        # Clean Light Navigation Sidebar
│   │   │   ├── StatusBadge.jsx    # Standardized metric status tags
│   │   │   ├── MetricModal.jsx    # Add/Edit Metric Dialog Form
      │   └── MetricDetailModal.jsx # View Metric metadata & Version Timeline
│   │   └── views/
│   │       ├── DashboardView.jsx  # Overview metrics & stats
│   │       ├── RepositoryView.jsx # Metric catalog list & filters
│   │       ├── ValidationView.jsx # SQL Validator & Recommendation workspace
│   │       ├── ConsistencyView.jsx# Cross-department repository audit scanner
│   │       ├── VersionHistoryView.jsx # Global audit log viewer
│   │       └── GuidelinesView.jsx # BI Semantic Layer reference guide
│   └── dist/                      # Compiled production assets
└── README.md
```

---

## How to Run the Project Locally

### Step 1: Start the Backend (FastAPI + SQLite)

1. Open a terminal window and navigate to the backend folder:
   ```bash
   cd backend
   ```

2. (Optional) Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Launch the FastAPI backend server:
   ```bash
   python run_backend.py
   ```
   *The backend will automatically start at `http://127.0.0.1:8000`, create `bi_semantic.db`, and seed initial sample metrics.*

   You can view interactive API documentation at `http://127.0.0.1:8000/docs`.

---

### Step 2: Start the Frontend (React + Vite)

1. Open a second terminal window and navigate to the frontend folder:
   ```bash
   cd frontend
   ```

2. (Optional) Install dependencies:
   ```bash
   npm install
   ```

3. Launch the React development server:
   ```bash
   npm run dev
   ```

4. Open your browser and go to:
   ```
   http://localhost:5173
   ```

---

## Sample Demonstration Queries for Project Presentation

When presenting this college project, demonstrate the SQL Validation and Consistency feature using these exact test cases:

### Test Case 1: Revenue Inconsistency (Gross vs Net Discount)
- **Selected Metric**: `Gross Revenue`
- **Approved Definition**: `SUM(order_amount)`
- **Submitted SQL Snippet**:
  ```sql
  SELECT SUM(order_amount - discount) FROM sales_orders WHERE order_status = 'completed';
  ```
- **Result**: System flags **`INCONSISTENT METRIC LOGIC`** and explains that discount deduction should be tracked separately as `Net Revenue`.
- **Recommendation**: System provides the standardized query:
  ```sql
  -- Standardized Approved SQL for 'Gross Revenue' (Semantic Layer)
  SELECT
    SUM(order_amount) AS gross_revenue
  FROM sales_orders
  WHERE order_status = 'completed';
  ```

---

### Test Case 2: Profit Margin Aggregation Mismatch
- **Selected Metric**: `Profit Margin`
- **Approved Definition**: `(SUM(revenue - cost) / SUM(revenue)) * 100`
- **Submitted SQL Snippet**:
  ```sql
  SELECT AVG(revenue - cost) FROM financial_ledger;
  ```
- **Result**: System flags **`Aggregation Mismatch`** (Submitted uses `AVG` instead of percentage ratio `SUM`).

---

### Test Case 3: Approved Metric Match
- **Selected Metric**: `Gross Revenue`
- **Submitted SQL Snippet**:
  ```sql
  SELECT SUM(order_amount) FROM sales_orders WHERE order_status = 'completed';
  ```
- **Result**: System returns **`APPROVED METRIC MATCH`**.

---

## Pre-Populated Sample Metrics

1. **Gross Revenue** (Approved) — `SUM(order_amount)`
2. **Net Revenue** (Pending Review) — `SUM(order_amount - discount_amount)`
3. **Profit Margin** (Approved) — `(SUM(revenue - cost) / SUM(revenue)) * 100`
4. **Customer Retention Rate** (Approved) — `(COUNT(DISTINCT active_retained_customers) / COUNT(DISTINCT total_start_customers)) * 100`
5. **Average Order Value (AOV)** (Approved) — `SUM(order_amount) / COUNT(DISTINCT order_id)`
6. **Customer Acquisition Cost (CAC)** (Inconsistent) — `SUM(marketing_spend) / COUNT(new_customers)`
7. **Monthly Active Users (MAU)** (Approved) — `COUNT(DISTINCT user_id)`
8. **Customer Churn Rate** (Approved) — `(COUNT(DISTINCT churned_users) / COUNT(DISTINCT total_active_users_start)) * 100`

---

## Design Specifications

- **Clean Light Dashboard Aesthetic**: Pure white background (`#FFFFFF`) with light subtle cards (`#F8FAFC`) and thin borders (`#E2E8F0`).
- **Color Accent Palette**: Light Blue (`#0EA5E9`), Green (`#10B981`), Purple (`#8B5CF6`), and Orange (`#F97316`).
- **No Dark Mode / Dark Sidebar**: Crisp light navigation sidebar with subtle hover/active states.
- **Lucide Icons**: Standardized icons for feature identification.
