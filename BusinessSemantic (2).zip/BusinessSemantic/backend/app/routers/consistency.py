from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Metric
from app.schemas import ConsistencyReport
from app.sql_engine import audit_repository_consistency
from datetime import datetime

router = APIRouter(prefix="/api/consistency", tags=["Consistency Audit"])

@router.get("/report", response_model=ConsistencyReport)
def get_consistency_report(db: Session = Depends(get_db)):
    """Run automated consistency audit scan across all metrics in the database."""
    metrics = db.query(Metric).all()
    
    # Convert metrics into dictionary list for analysis engine
    metric_dicts = [
        {
            "id": m.id,
            "name": m.name,
            "business_key": m.business_key,
            "department": m.department,
            "category": m.category,
            "definition": m.definition,
            "sql_formula": m.sql_formula,
            "status": m.status,
            "owner": m.owner
        }
        for m in metrics
    ]

    report = audit_repository_consistency(metric_dicts)
    report["timestamp"] = datetime.utcnow()
    return report
