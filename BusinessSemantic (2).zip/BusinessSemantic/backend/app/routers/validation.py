from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Metric, SQLValidationLog
from app.schemas import ValidationRequest, ValidationResultResponse
from app.sql_engine import validate_sql_against_metric
from datetime import datetime

router = APIRouter(prefix="/api/validation", tags=["SQL Validation"])

@router.post("", response_model=ValidationResultResponse)
def validate_sql_query(payload: ValidationRequest, db: Session = Depends(get_db)):
    """Validate submitted SQL code against the approved BI semantic metric definition."""
    metric = None
    if payload.metric_id:
        metric = db.query(Metric).filter(Metric.id == payload.metric_id).first()
    elif payload.metric_name:
        metric = db.query(Metric).filter(Metric.name.ilike(f"%{payload.metric_name}%")).first()

    if not metric:
        # Fallback to default Gross Revenue metric if none specified
        metric = db.query(Metric).filter(Metric.business_key == "revenue").first()

    if not metric:
        raise HTTPException(status_code=404, detail="No matching approved metric found for validation.")

    is_consistent, status_label, issues, discrepancy_details, recommended_sql = validate_sql_against_metric(
        submitted_sql=payload.submitted_sql,
        approved_formula=metric.sql_formula,
        metric_name=metric.name,
        table_name=metric.table_name or "orders",
        filter_condition=metric.filter_condition
    )

    log_entry = SQLValidationLog(
        metric_id=metric.id,
        metric_name=metric.name,
        submitted_sql=payload.submitted_sql,
        approved_formula=metric.sql_formula,
        validation_status=status_label,
        discrepancy_details=discrepancy_details,
        recommended_sql=recommended_sql,
        timestamp=datetime.utcnow()
    )
    db.add(log_entry)
    db.commit()
    db.refresh(log_entry)

    return ValidationResultResponse(
        id=log_entry.id,
        metric_id=metric.id,
        metric_name=metric.name,
        submitted_sql=payload.submitted_sql,
        approved_formula=metric.sql_formula,
        validation_status=status_label,
        is_consistent=is_consistent,
        discrepancy_details=discrepancy_details,
        recommended_sql=recommended_sql,
        issues_found=issues,
        timestamp=log_entry.timestamp
    )

@router.get("/logs")
def get_validation_logs(limit: int = 20, db: Session = Depends(get_db)):
    """Get recent validation history logs."""
    logs = db.query(SQLValidationLog)\
             .order_by(SQLValidationLog.timestamp.desc())\
             .limit(limit).all()
    return logs
