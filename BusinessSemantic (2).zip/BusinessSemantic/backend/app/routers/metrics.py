from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database import get_db
from app.models import Metric, MetricVersionHistory
from app.schemas import MetricCreate, MetricUpdate, MetricResponse, VersionHistoryResponse
from datetime import datetime

router = APIRouter(prefix="/api/metrics", tags=["Metrics Repository"])

@router.get("", response_model=List[MetricResponse])
def get_metrics(
    search: Optional[str] = None,
    department: Optional[str] = None,
    status: Optional[str] = None,
    category: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Retrieve all metrics with optional filtering and search."""
    query = db.query(Metric)

    if search:
        search_fmt = f"%{search}%"
        query = query.filter(
            (Metric.name.ilike(search_fmt)) |
            (Metric.business_key.ilike(search_fmt)) |
            (Metric.definition.ilike(search_fmt)) |
            (Metric.sql_formula.ilike(search_fmt)) |
            (Metric.owner.ilike(search_fmt))
        )

    if department and department != "All":
        query = query.filter(Metric.department == department)

    if status and status != "All":
        query = query.filter(Metric.status == status.upper())

    if category and category != "All":
        query = query.filter(Metric.category == category)

    return query.order_by(Metric.name.asc()).all()

@router.get("/{metric_id}", response_model=MetricResponse)
def get_metric(metric_id: int, db: Session = Depends(get_db)):
    """Retrieve a single metric by ID."""
    metric = db.query(Metric).filter(Metric.id == metric_id).first()
    if not metric:
        raise HTTPException(status_code=404, detail="Metric not found")
    return metric

@router.post("", response_model=MetricResponse, status_code=201)
def create_metric(metric_in: MetricCreate, db: Session = Depends(get_db)):
    """Create a new metric entry in the BI repository."""
    # Check business_key uniqueness
    existing = db.query(Metric).filter(Metric.business_key == metric_in.business_key.lower()).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"A metric with business key '{metric_in.business_key}' already exists."
        )

    change_reason = metric_in.change_reason or "Initial metric creation"
    data = metric_in.dict(exclude={"change_reason"})
    data["business_key"] = data["business_key"].lower().strip()

    new_metric = Metric(**data, version="1.0")
    db.add(new_metric)
    db.flush()

    # Record version 1.0 in history
    history_entry = MetricVersionHistory(
        metric_id=new_metric.id,
        version="1.0",
        previous_formula=None,
        new_formula=new_metric.sql_formula,
        change_reason=change_reason,
        changed_by=new_metric.owner,
        timestamp=datetime.utcnow()
    )
    db.add(history_entry)
    db.commit()
    db.refresh(new_metric)

    return new_metric

@router.put("/{metric_id}", response_model=MetricResponse)
def update_metric(metric_id: int, metric_in: MetricUpdate, db: Session = Depends(get_db)):
    """Update an existing metric and record a new version entry if SQL formula changes."""
    metric = db.query(Metric).filter(Metric.id == metric_id).first()
    if not metric:
        raise HTTPException(status_code=404, detail="Metric not found")

    old_formula = metric.sql_formula
    update_data = metric_in.dict(exclude_unset=True)

    change_reason = update_data.pop("change_reason", "Updated metric specification")
    changed_by = update_data.pop("changed_by", metric.owner)

    formula_changed = "sql_formula" in update_data and update_data["sql_formula"] != old_formula

    # If formula changed, bump version (e.g. 1.0 -> 1.1)
    if formula_changed:
        try:
            parts = metric.version.split('.')
            new_minor = int(parts[1]) + 1 if len(parts) > 1 else 1
            new_version = f"{parts[0]}.{new_minor}"
        except Exception:
            new_version = "1.1"
        metric.version = new_version

    for field, val in update_data.items():
        setattr(metric, field, val)

    metric.updated_at = datetime.utcnow()

    if formula_changed:
        history_entry = MetricVersionHistory(
            metric_id=metric.id,
            version=metric.version,
            previous_formula=old_formula,
            new_formula=metric.sql_formula,
            change_reason=change_reason,
            changed_by=changed_by,
            timestamp=datetime.utcnow()
        )
        db.add(history_entry)

    db.commit()
    db.refresh(metric)
    return metric

@router.delete("/{metric_id}", status_code=204)
def delete_metric(metric_id: int, db: Session = Depends(get_db)):
    """Delete a metric from repository."""
    metric = db.query(Metric).filter(Metric.id == metric_id).first()
    if not metric:
        raise HTTPException(status_code=404, detail="Metric not found")

    db.delete(metric)
    db.commit()
    return None

@router.get("/{metric_id}/history", response_model=List[VersionHistoryResponse])
def get_metric_version_history(metric_id: int, db: Session = Depends(get_db)):
    """Get full version audit history for a specific metric."""
    metric = db.query(Metric).filter(Metric.id == metric_id).first()
    if not metric:
        raise HTTPException(status_code=404, detail="Metric not found")

    return db.query(MetricVersionHistory)\
             .filter(MetricVersionHistory.metric_id == metric_id)\
             .order_by(MetricVersionHistory.timestamp.desc()).all()
