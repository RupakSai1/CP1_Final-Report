from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app.models import Metric, SQLValidationLog
from app.schemas import DashboardStats

router = APIRouter(prefix="/api/analytics", tags=["Dashboard Analytics"])

@router.get("/dashboard", response_model=DashboardStats)
def get_dashboard_stats(db: Session = Depends(get_db)):
    """Fetch aggregated summary statistics for the BI Semantic Dashboard."""
    total_metrics = db.query(Metric).count()
    approved_metrics = db.query(Metric).filter(Metric.status == "APPROVED").count()
    pending_metrics = db.query(Metric).filter(Metric.status == "PENDING").count()
    inconsistent_metrics = db.query(Metric).filter(Metric.status == "INCONSISTENT").count()

    # Department Breakdown
    dept_counts = db.query(Metric.department, func.count(Metric.id))\
                    .group_by(Metric.department).all()
    department_distribution = {dept: count for dept, count in dept_counts}

    # Status Breakdown
    status_counts = db.query(Metric.status, func.count(Metric.id))\
                      .group_by(Metric.status).all()
    status_distribution = {status: count for status, count in status_counts}

    # Recent Validations
    recent_logs = db.query(SQLValidationLog)\
                    .order_by(SQLValidationLog.timestamp.desc())\
                    .limit(5).all()

    recent_validations_list = [
        {
            "id": log.id,
            "metric_name": log.metric_name,
            "validation_status": log.validation_status,
            "timestamp": log.timestamp.isoformat()
        }
        for log in recent_logs
    ]

    return DashboardStats(
        total_metrics=total_metrics,
        approved_metrics=approved_metrics,
        pending_metrics=pending_metrics,
        inconsistent_metrics=inconsistent_metrics,
        department_distribution=department_distribution,
        status_distribution=status_distribution,
        recent_validations=recent_validations_list
    )
