from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

# --- Metric Schemas ---

class MetricBase(BaseModel):
    name: str = Field(..., example="Total Revenue")
    business_key: str = Field(..., example="revenue")
    department: str = Field(..., example="Finance")
    category: str = Field(..., example="Revenue")
    definition: str = Field(..., example="Total monetary value of completed sales orders before tax.")
    sql_formula: str = Field(..., example="SUM(order_amount)")
    aggregation_type: str = Field(..., example="SUM")
    table_name: Optional[str] = Field("orders", example="orders")
    dimensions: Optional[str] = Field("region, channel, date", example="region, channel, date")
    filter_condition: Optional[str] = Field("status = 'completed'", example="status = 'completed'")
    owner: str = Field(..., example="Finance Analytics Team")
    status: str = Field("APPROVED", example="APPROVED")

class MetricCreate(MetricBase):
    change_reason: Optional[str] = "Initial metric release"

class MetricUpdate(BaseModel):
    name: Optional[str] = None
    department: Optional[str] = None
    category: Optional[str] = None
    definition: Optional[str] = None
    sql_formula: Optional[str] = None
    aggregation_type: Optional[str] = None
    table_name: Optional[str] = None
    dimensions: Optional[str] = None
    filter_condition: Optional[str] = None
    owner: Optional[str] = None
    status: Optional[str] = None
    change_reason: Optional[str] = "Updated metric specification"
    changed_by: Optional[str] = "Data Steward"

class VersionHistoryResponse(BaseModel):
    id: int
    metric_id: int
    version: str
    previous_formula: Optional[str]
    new_formula: str
    change_reason: str
    changed_by: str
    timestamp: datetime

    class Config:
        from_attributes = True

class MetricResponse(MetricBase):
    id: int
    version: str
    created_at: datetime
    updated_at: datetime
    history: List[VersionHistoryResponse] = []

    class Config:
        from_attributes = True

# --- Validation Schemas ---

class ValidationRequest(BaseModel):
    metric_id: Optional[int] = None
    metric_name: Optional[str] = None
    submitted_sql: str = Field(..., example="SELECT SUM(order_amount - discount) FROM orders WHERE status = 'completed'")

class ValidationResultResponse(BaseModel):
    id: Optional[int] = None
    metric_id: Optional[int] = None
    metric_name: str
    submitted_sql: str
    approved_formula: str
    validation_status: str  # APPROVED_MATCH or INCONSISTENT
    is_consistent: bool
    discrepancy_details: str
    recommended_sql: str
    issues_found: List[str] = []
    timestamp: datetime

# --- Consistency Audit Schemas ---

class ConsistencyIssue(BaseModel):
    type: str  # DUPLICATE_KEY, FORMULA_MISMATCH, DEPARTMENT_DRIFT, UNAPPROVED_AGGREGATION
    metric_name: str
    business_key: str
    departments_involved: List[str]
    description: str
    severity: str  # HIGH, MEDIUM, LOW
    recommendation: str

class ConsistencyReport(BaseModel):
    total_metrics_audited: int
    approved_count: int
    pending_count: int
    inconsistent_count: int
    health_score: float  # Percentage e.g. 87.5%
    issues: List[ConsistencyIssue]
    timestamp: datetime

# --- Analytics / Dashboard Schemas ---

class DashboardStats(BaseModel):
    total_metrics: int
    approved_metrics: int
    pending_metrics: int
    inconsistent_metrics: int
    department_distribution: dict
    status_distribution: dict
    recent_validations: List[dict]
