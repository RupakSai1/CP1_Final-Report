import re
from typing import Dict, List, Tuple, Any

def normalize_sql(sql: str) -> str:
    """Strip extra whitespaces and standardize SQL for analysis."""
    if not sql:
        return ""
    # Remove newlines and multiple spaces
    cleaned = re.sub(r'\s+', ' ', sql.strip())
    return cleaned

def extract_formula_expression(sql: str) -> str:
    """
    Extract the core expression inside SELECT or raw formula string.
    Example: 'SELECT SUM(order_amount) FROM orders' -> 'SUM(order_amount)'
    """
    cleaned = normalize_sql(sql)
    
    # If full SELECT statement is passed
    match = re.search(r'SELECT\s+(.*?)\s+(?:FROM|\Z)', cleaned, re.IGNORECASE)
    if match:
        expr = match.group(1).strip()
        # strip column aliases like 'AS total_revenue'
        expr = re.sub(r'\s+AS\s+\w+', '', expr, flags=re.IGNORECASE)
        return expr
    
    return cleaned

def validate_sql_against_metric(
    submitted_sql: str,
    approved_formula: str,
    metric_name: str,
    table_name: str = "orders",
    filter_condition: str = None
) -> Tuple[bool, str, List[str], str]:
    """
    Compares submitted SQL against approved metric formula.
    Returns:
      is_consistent (bool)
      status_label ("APPROVED_MATCH" | "INCONSISTENT")
      issues (List[str])
      discrepancy_details (str)
      recommended_sql (str)
    """
    sub_clean = normalize_sql(submitted_sql)
    app_clean = normalize_sql(approved_formula)
    
    sub_expr = extract_formula_expression(submitted_sql)
    app_expr = extract_formula_expression(approved_formula)
    
    issues = []
    
    # 1. Exact match check
    if sub_expr.upper() == app_expr.upper() or sub_clean.upper() == app_clean.upper():
        is_consistent = True
        status_label = "APPROVED_MATCH"
        details = "Submitted SQL perfectly matches the approved semantic layer definition."
    else:
        # Check specific pattern discrepancies
        is_consistent = False
        status_label = "INCONSISTENT"
        
        # Check 1: Discount subtraction discrepancy (e.g., order_amount - discount)
        if "- DISCOUNT" in sub_expr.upper() and "- DISCOUNT" not in app_expr.upper():
            issues.append("Unapproved Discount Deduction: Submitted logic subtracts discount directly from gross amount.")
        elif "DISCOUNT" in app_expr.upper() and "DISCOUNT" not in sub_expr.upper():
            issues.append("Missing Discount Logic: Approved formula requires discount deduction.")

        # Check 2: Aggregation function mismatch (SUM vs AVG vs COUNT)
        sub_agg_match = re.search(r'\b(SUM|AVG|COUNT|MAX|MIN)\b', sub_expr.upper())
        app_agg_match = re.search(r'\b(SUM|AVG|COUNT|MAX|MIN)\b', app_expr.upper())
        
        sub_agg = sub_agg_match.group(1) if sub_agg_match else None
        app_agg = app_agg_match.group(1) if app_agg_match else None
        
        if sub_agg and app_agg and sub_agg != app_agg:
            issues.append(f"Aggregation Mismatch: Submitted uses '{sub_agg}' but approved semantic standard requires '{app_agg}'.")
            
        # Check 3: Column reference differences
        sub_cols = set(re.findall(r'\b[a_z0_9_]+\b', sub_expr.lower())) - {'select', 'from', 'where', 'as', 'sum', 'avg', 'count', 'distinct', 'case', 'when', 'then', 'else', 'end', 'min', 'max'}
        app_cols = set(re.findall(r'\b[a_z0_9_]+\b', app_expr.lower())) - {'select', 'from', 'where', 'as', 'sum', 'avg', 'count', 'distinct', 'case', 'when', 'then', 'else', 'end', 'min', 'max'}
        
        diff_sub = sub_cols - app_cols
        if diff_sub:
            issues.append(f"Non-Standard Column Usage: Submitted logic references column(s) {list(diff_sub)} not present in the approved formula.")
            
        # Check 4: Missing WHERE clause / filter condition
        if filter_condition and filter_condition.lower() not in sub_clean.lower():
            issues.append(f"Missing Standard Filter: Approved metric requires filter condition '{filter_condition}'.")

        if not issues:
            issues.append(f"Formula Logic Mismatch: Submitted expression '{sub_expr}' differs from approved expression '{app_expr}'.")
            
        details = f"INCONSISTENT METRIC DEFINITION:\n" + "\n".join([f"• {issue}" for issue in issues])
        details += f"\n\nApproved Definition: {app_expr}"
        details += f"\nSubmitted Definition: {sub_expr}"

    # Build standardized recommended SQL statement
    table = table_name if table_name else "orders"
    where_clause = f"\nWHERE {filter_condition}" if filter_condition else ""
    recommended_sql = f"-- Standardized Approved SQL for '{metric_name}' (Semantic Layer)\nSELECT\n  {approved_formula} AS {re.sub(r'[^a_z0_9_]', '_', metric_name.lower())}\nFROM {table}{where_clause};"
    
    return is_consistent, status_label, issues, details, recommended_sql


def audit_repository_consistency(metrics: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Audits all metrics in repository to find duplicate business keys,
    conflicting definitions across departments, or unapproved formula patterns.
    """
    issues = []
    keys_seen = {}
    dept_metrics = {}
    
    total = len(metrics)
    approved = 0
    pending = 0
    inconsistent = 0
    
    for m in metrics:
        status = m.get('status', 'APPROVED').upper()
        if status == 'APPROVED':
            approved += 1
        elif status == 'PENDING':
            pending += 1
        elif status == 'INCONSISTENT':
            inconsistent += 1
            
        bkey = m.get('business_key', '').lower().strip()
        dept = m.get('department', 'General')
        name = m.get('name', '')
        formula = m.get('sql_formula', '')
        
        # Check 1: Duplicate business key with different formulas
        if bkey in keys_seen:
            prev = keys_seen[bkey]
            if prev['sql_formula'].strip().upper() != formula.strip().upper():
                issues.append({
                    "type": "DUPLICATE_KEY_MISMATCH",
                    "metric_name": name,
                    "business_key": bkey,
                    "departments_involved": [prev['department'], dept],
                    "description": f"Metric business key '{bkey}' is defined differently in {prev['department']} ('{prev['sql_formula']}') and {dept} ('{formula}').",
                    "severity": "HIGH",
                    "recommendation": f"Standardize '{bkey}' across all departments using a unified semantic layer entry."
                })
        else:
            keys_seen[bkey] = m
            
        # Check 2: Metric flagged as INCONSISTENT in repository
        if status == 'INCONSISTENT':
            issues.append({
                "type": "FLAGGED_INCONSISTENT",
                "metric_name": name,
                "business_key": bkey,
                "departments_involved": [dept],
                "description": f"Metric '{name}' in department '{dept}' is marked as INCONSISTENT in metadata.",
                "severity": "MEDIUM",
                "recommendation": "Review metric specification with data steward and submit updated version."
            })

    # Health score calculation (100% if no issues/inconsistent)
    health_score = round(max(0, 100 - (len(issues) * 12.5)), 1)
    
    return {
        "total_metrics_audited": total,
        "approved_count": approved,
        "pending_count": pending,
        "inconsistent_count": inconsistent,
        "health_score": health_score,
        "issues": issues
    }
