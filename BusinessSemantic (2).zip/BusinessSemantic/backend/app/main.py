from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine, Base, SessionLocal
from app.seed_data import seed_sample_data
from app.routers import metrics, validation, consistency, analytics

# Create database tables automatically
Base.metadata.create_all(bind=engine)

# Populate initial sample BI metrics if database is fresh
db = SessionLocal()
try:
    seed_sample_data(db)
finally:
    db.close()

app = FastAPI(
    title="BI Semantic Layer & Metric Consistency API",
    description="Backend service providing metric governance, version tracking, SQL semantic validation, and metric consistency reporting.",
    version="1.0.0"
)

# Enable CORS for React frontend development
origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "*"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Routers
app.include_router(analytics.router)
app.include_router(metrics.router)
app.include_router(validation.router)
app.include_router(consistency.router)

@app.get("/")
def root():
    return {
        "status": "online",
        "service": "BI Semantic Layer API",
        "version": "1.0.0",
        "docs_url": "/docs"
    }
