from sqlalchemy.orm import Session
from app.models import Metric, MetricVersionHistory, SQLValidationLog
from datetime import datetime, timedelta

def seed_sample_data(db: Session):
    """Seed initial BI metrics if database is empty."""
    if db.query(Metric).first() is not None:
        return  # Data already exists

    print("Seeding initial BI Semantic Layer metrics...")

    sample_metrics = [
        {
            "name": "Gross Revenue",
            "business_key": "revenue",
            "department": "Finance",
            "category": "Financial",
            "definition": "Total monetary gross revenue generated from completed customer sales orders before discounts and tax.",
            "sql_formula": "SUM(order_amount)",
            "aggregation_type": "SUM",
            "table_name": "sales_orders",
            "dimensions": "region, sales_channel, product_category, order_date",
            "filter_condition": "order_status = 'completed'",
            "owner": "Finance Analytics (Sarah Jenkins)",
            "version": "1.2",
            "status": "APPROVED",
            "history": [
                {
                    "version": "1.0",
                    "previous_formula": None,
                    "new_formula": "SUM(amount)",
                    "change_reason": "Initial definition created for Q1 reporting.",
                    "changed_by": "Sarah Jenkins",
                    "timestamp": datetime.utcnow() - timedelta(days=60)
                },
                {
                    "version": "1.2",
                    "previous_formula": "SUM(amount)",
                    "new_formula": "SUM(order_amount)",
                    "change_reason": "Standardized column naming to match unified data warehouse model.",
                    "changed_by": "Sarah Jenkins",
                    "timestamp": datetime.utcnow() - timedelta(days=15)
                }
            ]
        },
        {
            "name": "Net Revenue",
            "business_key": "net_revenue",
            "department": "Finance",
            "category": "Financial",
            "definition": "Net revenue calculated by deducting order discounts and promo codes from gross order amounts.",
            "sql_formula": "SUM(order_amount - discount_amount)",
            "aggregation_type": "SUM",
            "table_name": "sales_orders",
            "dimensions": "region, sales_channel, product_category",
            "filter_condition": "order_status = 'completed'",
            "owner": "Finance Analytics (Sarah Jenkins)",
            "version": "1.0",
            "status": "PENDING",
            "history": [
                {
                    "version": "1.0",
                    "previous_formula": None,
                    "new_formula": "SUM(order_amount - discount_amount)",
                    "change_reason": "Submitted for approval to distinguish Gross vs Net Revenue.",
                    "changed_by": "Sarah Jenkins",
                    "timestamp": datetime.utcnow() - timedelta(days=5)
                }
            ]
        },
        {
            "name": "Profit Margin",
            "business_key": "profit_margin",
            "department": "Finance",
            "category": "Profitability",
            "definition": "Percentage of net sales revenue retained after accounting for direct cost of goods sold (COGS).",
            "sql_formula": "(SUM(revenue - cost) / SUM(revenue)) * 100",
            "aggregation_type": "PERCENTAGE",
            "table_name": "financial_ledger",
            "dimensions": "business_unit, region, fiscal_quarter",
            "filter_condition": "ledger_status = 'posted'",
            "owner": "CFO Office (David Miller)",
            "version": "1.1",
            "status": "APPROVED",
            "history": [
                {
                    "version": "1.0",
                    "previous_formula": None,
                    "new_formula": "(SUM(revenue - cost) / SUM(revenue))",
                    "change_reason": "Initial formula drafted as raw ratio.",
                    "changed_by": "David Miller",
                    "timestamp": datetime.utcnow() - timedelta(days=45)
                },
                {
                    "version": "1.1",
                    "previous_formula": "(SUM(revenue - cost) / SUM(revenue))",
                    "new_formula": "(SUM(revenue - cost) / SUM(revenue)) * 100",
                    "change_reason": "Formatted formula to produce 0-100 percentage values for BI dashboards.",
                    "changed_by": "David Miller",
                    "timestamp": datetime.utcnow() - timedelta(days=10)
                }
            ]
        },
        {
            "name": "Customer Retention Rate",
            "business_key": "customer_retention_rate",
            "department": "Marketing",
            "category": "Retention",
            "definition": "Percentage of existing customers who remain active and make repeat purchases during the period.",
            "sql_formula": "(COUNT(DISTINCT active_retained_customers) / COUNT(DISTINCT total_start_customers)) * 100",
            "aggregation_type": "PERCENTAGE",
            "table_name": "customer_cohorts",
            "dimensions": "cohort_month, customer_segment",
            "filter_condition": "is_active = 1",
            "owner": "Growth Operations (Elena Rostova)",
            "version": "1.0",
            "status": "APPROVED",
            "history": [
                {
                    "version": "1.0",
                    "previous_formula": None,
                    "new_formula": "(COUNT(DISTINCT active_retained_customers) / COUNT(DISTINCT total_start_customers)) * 100",
                    "change_reason": "Approved standardized cohort retention definition.",
                    "changed_by": "Elena Rostova",
                    "timestamp": datetime.utcnow() - timedelta(days=30)
                }
            ]
        },
        {
            "name": "Average Order Value",
            "business_key": "average_order_value",
            "department": "Sales",
            "category": "Sales Efficiency",
            "definition": "Average total monetary amount spent per completed order transaction across sales channels.",
            "sql_formula": "SUM(order_amount) / COUNT(DISTINCT order_id)",
            "aggregation_type": "RATIO",
            "table_name": "sales_orders",
            "dimensions": "device_type, sales_channel, customer_tier",
            "filter_condition": "order_status = 'completed'",
            "owner": "Sales Operations (Marcus Vance)",
            "version": "1.0",
            "status": "APPROVED",
            "history": [
                {
                    "version": "1.0",
                    "previous_formula": None,
                    "new_formula": "SUM(order_amount) / COUNT(DISTINCT order_id)",
                    "change_reason": "Initial standardized metric definition.",
                    "changed_by": "Marcus Vance",
                    "timestamp": datetime.utcnow() - timedelta(days=25)
                }
            ]
        },
        {
            "name": "Customer Acquisition Cost",
            "business_key": "customer_acquisition_cost",
            "department": "Marketing",
            "category": "Acquisition",
            "definition": "Total marketing and ad spend divided by new customer count. Flagged due to conflicting attribution windows.",
            "sql_formula": "SUM(marketing_spend) / COUNT(new_customers)",
            "aggregation_type": "RATIO",
            "table_name": "marketing_campaigns",
            "dimensions": "ad_channel, campaign_type",
            "filter_condition": "channel != 'organic'",
            "owner": "Performance Marketing (Alex Chen)",
            "version": "1.0",
            "status": "INCONSISTENT",
            "history": [
                {
                    "version": "1.0",
                    "previous_formula": None,
                    "new_formula": "SUM(marketing_spend) / COUNT(new_customers)",
                    "change_reason": "Flagged as inconsistent: missing 30-day attribution window filter.",
                    "changed_by": "Alex Chen",
                    "timestamp": datetime.utcnow() - timedelta(days=8)
                }
            ]
        },
        {
            "name": "Monthly Active Users",
            "business_key": "monthly_active_users",
            "department": "Product",
            "category": "Product Engagement",
            "definition": "Count of unique authenticated users who logged in or performed a key action within the last 30 days.",
            "sql_formula": "COUNT(DISTINCT user_id)",
            "aggregation_type": "COUNT",
            "table_name": "product_events",
            "dimensions": "platform, user_country, subscription_tier",
            "filter_condition": "last_event_timestamp >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)",
            "owner": "Product Data Team (Priya Sharma)",
            "version": "1.1",
            "status": "APPROVED",
            "history": [
                {
                    "version": "1.0",
                    "previous_formula": None,
                    "new_formula": "COUNT(user_id)",
                    "change_reason": "Draft formula (counted total events instead of distinct users).",
                    "changed_by": "Priya Sharma",
                    "timestamp": datetime.utcnow() - timedelta(days=40)
                },
                {
                    "version": "1.1",
                    "previous_formula": "COUNT(user_id)",
                    "new_formula": "COUNT(DISTINCT user_id)",
                    "change_reason": "Updated to DISTINCT count to prevent double counting multi-session users.",
                    "changed_by": "Priya Sharma",
                    "timestamp": datetime.utcnow() - timedelta(days=12)
                }
            ]
        },
        {
            "name": "Customer Churn Rate",
            "business_key": "churn_rate",
            "department": "Customer Success",
            "category": "Retention",
            "definition": "Percentage of active recurring subscribers who canceled or lapsed during the current month.",
            "sql_formula": "(COUNT(DISTINCT churned_users) / COUNT(DISTINCT total_active_users_start)) * 100",
            "aggregation_type": "PERCENTAGE",
            "table_name": "subscriptions",
            "dimensions": "plan_type, billing_cycle",
            "filter_condition": "account_status = 'canceled'",
            "owner": "Customer Success (Tom Bradley)",
            "version": "1.0",
            "status": "APPROVED",
            "history": [
                {
                    "version": "1.0",
                    "previous_formula": None,
                    "new_formula": "(COUNT(DISTINCT churned_users) / COUNT(DISTINCT total_active_users_start)) * 100",
                    "change_reason": "Approved standardized churn metric.",
                    "changed_by": "Tom Bradley",
                    "timestamp": datetime.utcnow() - timedelta(days=20)
                }
            ]
        }
    ]

    for m_data in sample_metrics:
        history_items = m_data.pop("history", [])
        metric_obj = Metric(**m_data)
        db.add(metric_obj)
        db.flush()  # Get metric_obj.id

        for hist in history_items:
            version_obj = MetricVersionHistory(
                metric_id=metric_obj.id,
                **hist
            )
            db.add(version_obj)

    # Seed sample validation logs
    rev_metric = db.query(Metric).filter(Metric.business_key == "revenue").first()
    if rev_metric:
        log1 = SQLValidationLog(
            metric_id=rev_metric.id,
            metric_name=rev_metric.name,
            submitted_sql="SELECT SUM(order_amount - discount) FROM sales_orders WHERE order_status = 'completed'",
            approved_formula="SUM(order_amount)",
            validation_status="INCONSISTENT",
            discrepancy_details="INCONSISTENT METRIC DEFINITION:\n• Unapproved Discount Deduction: Submitted logic subtracts discount directly from gross amount.\n\nApproved Definition: SUM(order_amount)\nSubmitted Definition: SUM(order_amount - discount)",
            recommended_sql="-- Standardized Approved SQL for 'Gross Revenue' (Semantic Layer)\nSELECT\n  SUM(order_amount) AS gross_revenue\nFROM sales_orders\nWHERE order_status = 'completed';",
            timestamp=datetime.utcnow() - timedelta(hours=2)
        )
        log2 = SQLValidationLog(
            metric_id=rev_metric.id,
            metric_name=rev_metric.name,
            submitted_sql="SELECT SUM(order_amount) FROM sales_orders WHERE order_status = 'completed'",
            approved_formula="SUM(order_amount)",
            validation_status="APPROVED_MATCH",
            discrepancy_details="Submitted SQL perfectly matches the approved semantic layer definition.",
            recommended_sql="-- Standardized Approved SQL for 'Gross Revenue' (Semantic Layer)\nSELECT\n  SUM(order_amount) AS gross_revenue\nFROM sales_orders\nWHERE order_status = 'completed';",
            timestamp=datetime.utcnow() - timedelta(minutes=45)
        )
        db.add(log1)
        db.add(log2)

    db.commit()
    print("Database successfully populated with BI sample data!")
