from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class Metric(Base):
    __tablename__ = "metrics"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    business_key = Column(String(100), unique=True, index=True, nullable=False)
    department = Column(String(50), nullable=False, index=True)
    category = Column(String(50), nullable=False, index=True)
    definition = Column(Text, nullable=False)
    sql_formula = Column(Text, nullable=False)
    aggregation_type = Column(String(30), nullable=False)  # SUM, AVG, COUNT, RATIO, etc.
    table_name = Column(String(100), nullable=True, default="orders")
    dimensions = Column(Text, nullable=True)
    filter_condition = Column(Text, nullable=True)
    owner = Column(String(100), nullable=False)
    version = Column(String(20), nullable=False, default="1.0")
    status = Column(String(20), nullable=False, default="APPROVED")  # APPROVED, PENDING, INCONSISTENT, DEPRECATED
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    history = relationship("MetricVersionHistory", back_populates="metric", cascade="all, delete-orphan")
    validations = relationship("SQLValidationLog", back_populates="metric", cascade="all, delete-orphan")


class MetricVersionHistory(Base):
    __tablename__ = "metric_version_history"

    id = Column(Integer, primary_key=True, index=True)
    metric_id = Column(Integer, ForeignKey("metrics.id", ondelete="CASCADE"), nullable=False)
    version = Column(String(20), nullable=False)
    previous_formula = Column(Text, nullable=True)
    new_formula = Column(Text, nullable=False)
    change_reason = Column(Text, nullable=False)
    changed_by = Column(String(100), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    metric = relationship("Metric", back_populates="history")


class SQLValidationLog(Base):
    __tablename__ = "sql_validation_logs"

    id = Column(Integer, primary_key=True, index=True)
    metric_id = Column(Integer, ForeignKey("metrics.id", ondelete="SET NULL"), nullable=True)
    metric_name = Column(String(100), nullable=False)
    submitted_sql = Column(Text, nullable=False)
    approved_formula = Column(Text, nullable=False)
    validation_status = Column(String(30), nullable=False)  # APPROVED_MATCH, INCONSISTENT
    discrepancy_details = Column(Text, nullable=False)
    recommended_sql = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    metric = relationship("Metric", back_populates="validations")
