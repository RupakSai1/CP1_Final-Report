import React from 'react';
import { Search, Database, Layers, CheckCircle2 } from 'lucide-react';

export const Header = ({ activeTab, searchTerm, setSearchTerm }) => {
  const getTabTitle = () => {
    switch (activeTab) {
      case 'dashboard': return 'Semantic Layer Overview';
      case 'repository': return 'Business Metric Repository';
      case 'validation': return 'SQL Semantic Validator';
      case 'consistency': return 'Metric Consistency Auditor';
      case 'history': return 'Version Audit Trail';
      case 'guidelines': return 'Governance Guidelines';
      default: return 'BI Semantic Platform';
    }
  };

  return (
    <header style={{
      backgroundColor: '#FFFFFF',
      borderBottom: '1px solid #E2E8F0',
      padding: '16px 32px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '20px'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{
          backgroundColor: '#E0F2FE',
          color: '#0EA5E9',
          padding: '8px',
          borderRadius: '8px',
          display: 'flex',
          alignItems: 'center'
        }}>
          <Layers size={20} />
        </div>
        <div>
          <h1 style={{ fontSize: '18px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
            {getTabTitle()}
          </h1>
          <p style={{ fontSize: '12px', color: '#64748B', margin: 0 }}>
            College BI Semantic Layer & Definition Consistency Engine
          </p>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        {/* Search Bar */}
        <div style={{ position: 'relative', width: '260px' }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94A3B8' }} />
          <input
            type="text"
            placeholder="Search metrics or SQL..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-control"
            style={{ paddingLeft: '36px', height: '36px', fontSize: '13px' }}
          />
        </div>

        {/* Backend Engine Online Status Badge */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          backgroundColor: '#F0FDF4',
          border: '1px solid #DCFCE7',
          padding: '6px 12px',
          borderRadius: '20px',
          fontSize: '12px',
          fontWeight: 500,
          color: '#166534'
        }}>
          <CheckCircle2 size={14} color="#16A34A" />
          <span>Engine: Active (SQLite)</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
