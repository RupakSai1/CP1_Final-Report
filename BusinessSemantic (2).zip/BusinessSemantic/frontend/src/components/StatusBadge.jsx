import React from 'react';
import { CheckCircle2, Clock, AlertTriangle, XCircle } from 'lucide-react';

export const StatusBadge = ({ status }) => {
  const normalized = (status || '').toUpperCase();

  switch (normalized) {
    case 'APPROVED':
    case 'APPROVED_MATCH':
      return (
        <span className="badge badge-approved">
          <CheckCircle2 size={13} />
          Approved
        </span>
      );
    case 'PENDING':
      return (
        <span className="badge badge-pending">
          <Clock size={13} />
          Pending Review
        </span>
      );
    case 'INCONSISTENT':
      return (
        <span className="badge badge-inconsistent">
          <AlertTriangle size={13} />
          Inconsistent
        </span>
      );
    case 'DEPRECATED':
      return (
        <span className="badge badge-danger">
          <XCircle size={13} />
          Deprecated
        </span>
      );
    default:
      return (
        <span className="badge badge-pending">
          {status}
        </span>
      );
  }
};

export default StatusBadge;
