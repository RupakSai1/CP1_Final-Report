import React from 'react';
import { 
  LayoutDashboard, 
  Database, 
  Code2, 
  GitCompare, 
  History, 
  BookOpen, 
  Sparkles,
  ShieldCheck
} from 'lucide-react';

export const Sidebar = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: null },
    { id: 'repository', label: 'Metric Repository', icon: Database, badge: null },
    { id: 'validation', label: 'SQL Validation', icon: Code2, badge: 'Live' },
    { id: 'consistency', label: 'Consistency Checker', icon: GitCompare, badge: null },
    { id: 'history', label: 'Version History', icon: History, badge: null },
    { id: 'guidelines', label: 'BI Guidelines', icon: BookOpen, badge: null }
  ];

  return (
    <aside style={{
      width: '250px',
      backgroundColor: '#FFFFFF',
      borderRight: '1px solid #E2E8F0',
      display: 'flex',
      flexDirection: 'column',
      justify: 'space-between',
      padding: '20px 16px',
      height: '100vh',
      position: 'sticky',
      top: 0
    }}>
      <div>
        {/* Brand Logo */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          padding: '8px 12px',
          marginBottom: '24px'
        }}>
          <div style={{
            backgroundColor: '#0EA5E9',
            color: '#FFFFFF',
            padding: '8px',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <ShieldCheck size={22} />
          </div>
          <div>
            <h2 style={{ fontSize: '15px', fontWeight: 700, color: '#0F172A', lineHeight: 1.2 }}>
              SemanticLayer
            </h2>
            <span style={{ fontSize: '11px', color: '#0EA5E9', fontWeight: 600 }}>
              Consistency BI v1.0
            </span>
          </div>
        </div>

        {/* Menu Navigation */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <div style={{
            fontSize: '11px',
            fontWeight: 600,
            color: '#94A3B8',
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            padding: '8px 12px',
            marginBottom: '4px'
          }}>
            Main Menu
          </div>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  width: '100%',
                  padding: '10px 14px',
                  borderRadius: '8px',
                  border: 'none',
                  backgroundColor: isActive ? '#F0F9FF' : 'transparent',
                  color: isActive ? '#0284C7' : '#475569',
                  fontWeight: isActive ? 600 : 500,
                  fontSize: '13.5px',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  textAlign: 'left'
                }}
                onMouseEnter={(e) => {
                  if (!isActive) e.currentTarget.style.backgroundColor = '#F8FAFC';
                }}
                onMouseLeave={(e) => {
                  if (!isActive) e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <Icon size={18} color={isActive ? '#0EA5E9' : '#64748B'} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span style={{
                    fontSize: '10px',
                    fontWeight: 700,
                    backgroundColor: '#E0F2FE',
                    color: '#0284C7',
                    padding: '2px 6px',
                    borderRadius: '4px'
                  }}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* College Project Footer Box */}
      <div style={{
        backgroundColor: '#F8FAFC',
        border: '1px solid #E2E8F0',
        borderRadius: '10px',
        padding: '14px',
        fontSize: '12px',
        color: '#475569'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 600, color: '#0F172A', marginBottom: '4px' }}>
          <Sparkles size={14} color="#8B5CF6" />
          <span>College Project</span>
        </div>
        <p style={{ margin: 0, fontSize: '11px', color: '#64748B' }}>
          Standardizing SQL Metrics & Definitions across Enterprise BI.
        </p>
      </div>
    </aside>
  );
};

export default Sidebar;
