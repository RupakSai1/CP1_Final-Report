import React, { useState, useEffect } from 'react';
import { X, CheckCircle, Database } from 'lucide-react';

export const MetricModal = ({ isOpen, onClose, onSave, metricToEdit }) => {
  const [formData, setFormData] = useState({
    name: '',
    business_key: '',
    department: 'Finance',
    category: 'Financial',
    definition: '',
    sql_formula: '',
    aggregation_type: 'SUM',
    table_name: 'sales_orders',
    dimensions: 'region, date, channel',
    filter_condition: "status = 'completed'",
    owner: 'Data Governance Team',
    status: 'APPROVED',
    change_reason: ''
  });

  const [error, setError] = useState('');

  useEffect(() => {
    if (metricToEdit) {
      setFormData({
        name: metricToEdit.name || '',
        business_key: metricToEdit.business_key || '',
        department: metricToEdit.department || 'Finance',
        category: metricToEdit.category || 'Financial',
        definition: metricToEdit.definition || '',
        sql_formula: metricToEdit.sql_formula || '',
        aggregation_type: metricToEdit.aggregation_type || 'SUM',
        table_name: metricToEdit.table_name || 'sales_orders',
        dimensions: metricToEdit.dimensions || '',
        filter_condition: metricToEdit.filter_condition || '',
        owner: metricToEdit.owner || '',
        status: metricToEdit.status || 'APPROVED',
        change_reason: ''
      });
    } else {
      setFormData({
        name: '',
        business_key: '',
        department: 'Finance',
        category: 'Financial',
        definition: '',
        sql_formula: '',
        aggregation_type: 'SUM',
        table_name: 'sales_orders',
        dimensions: 'region, date, channel',
        filter_condition: "status = 'completed'",
        owner: 'Data Governance Team',
        status: 'APPROVED',
        change_reason: 'Initial metric definition creation'
      });
    }
    setError('');
  }, [metricToEdit, isOpen]);

  if (!isOpen) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
      // Auto generate business key if creating new and typing name
      business_key: (name === 'name' && !metricToEdit) 
        ? value.toLowerCase().replace(/[^a-z0-9_]/g, '_').replace(/_+/g, '_') 
        : (name === 'business_key' ? value : prev.business_key)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.sql_formula || !formData.definition) {
      setError('Please fill in all required fields (Name, Definition, SQL Formula).');
      return;
    }
    onSave(formData);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ backgroundColor: '#E0F2FE', color: '#0EA5E9', padding: '6px', borderRadius: '6px' }}>
              <Database size={18} />
            </div>
            <h3 style={{ fontSize: '16px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
              {metricToEdit ? 'Edit Semantic Metric' : 'Create New Metric Definition'}
            </h3>
          </div>
          <button 
            onClick={onClose}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {error && (
              <div style={{
                backgroundColor: '#FEE2E2',
                border: '1px solid #FCA5A5',
                color: '#DC2626',
                padding: '10px 14px',
                borderRadius: '6px',
                fontSize: '13px'
              }}>
                {error}
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Metric Display Name *
                </label>
                <input
                  type="text"
                  name="name"
                  placeholder="e.g. Gross Revenue"
                  value={formData.name}
                  onChange={handleChange}
                  className="input-control"
                  required
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Business Key (Unique) *
                </label>
                <input
                  type="text"
                  name="business_key"
                  placeholder="e.g. gross_revenue"
                  value={formData.business_key}
                  onChange={handleChange}
                  className="input-control"
                  disabled={!!metricToEdit}
                  required
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Department
                </label>
                <select name="department" value={formData.department} onChange={handleChange} className="select-control">
                  <option value="Finance">Finance</option>
                  <option value="Sales">Sales</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Product">Product</option>
                  <option value="Customer Success">Customer Success</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Category
                </label>
                <select name="category" value={formData.category} onChange={handleChange} className="select-control">
                  <option value="Financial">Financial</option>
                  <option value="Profitability">Profitability</option>
                  <option value="Retention">Retention</option>
                  <option value="Sales Efficiency">Sales Efficiency</option>
                  <option value="Acquisition">Acquisition</option>
                  <option value="Product Engagement">Product Engagement</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Aggregation
                </label>
                <select name="aggregation_type" value={formData.aggregation_type} onChange={handleChange} className="select-control">
                  <option value="SUM">SUM</option>
                  <option value="AVG">AVG</option>
                  <option value="COUNT">COUNT</option>
                  <option value="RATIO">RATIO</option>
                  <option value="PERCENTAGE">PERCENTAGE</option>
                </select>
              </div>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                Business Definition *
              </label>
              <textarea
                name="definition"
                rows="2"
                placeholder="Describe what this metric measures in business terms..."
                value={formData.definition}
                onChange={handleChange}
                className="textarea-control"
                required
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                Approved Standard SQL Formula *
              </label>
              <input
                type="text"
                name="sql_formula"
                placeholder="e.g. SUM(order_amount) or (SUM(revenue - cost) / SUM(revenue)) * 100"
                value={formData.sql_formula}
                onChange={handleChange}
                className="input-control"
                style={{ fontFamily: 'Courier New, monospace', fontWeight: 600, color: '#0F172A' }}
                required
              />
              <span style={{ fontSize: '11px', color: '#64748B' }}>
                The semantic SQL expression that will be enforced across all BI tools and queries.
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Table Name
                </label>
                <input
                  type="text"
                  name="table_name"
                  value={formData.table_name}
                  onChange={handleChange}
                  className="input-control"
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Status
                </label>
                <select name="status" value={formData.status} onChange={handleChange} className="select-control">
                  <option value="APPROVED">APPROVED</option>
                  <option value="PENDING">PENDING</option>
                  <option value="INCONSISTENT">INCONSISTENT</option>
                  <option value="DEPRECATED">DEPRECATED</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Owner / Steward
                </label>
                <input
                  type="text"
                  name="owner"
                  value={formData.owner}
                  onChange={handleChange}
                  className="input-control"
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Filter Condition
                </label>
                <input
                  type="text"
                  name="filter_condition"
                  value={formData.filter_condition}
                  onChange={handleChange}
                  className="input-control"
                />
              </div>
            </div>

            {metricToEdit && (
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Change Description / Audit Note
                </label>
                <input
                  type="text"
                  name="change_reason"
                  placeholder="Reason for modifying this metric formula or metadata..."
                  value={formData.change_reason}
                  onChange={handleChange}
                  className="input-control"
                />
              </div>
            )}
          </div>

          <div className="modal-footer">
            <button type="button" onClick={onClose} className="btn btn-secondary">
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              <CheckCircle size={16} />
              {metricToEdit ? 'Save Changes' : 'Create Metric'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MetricModal;
