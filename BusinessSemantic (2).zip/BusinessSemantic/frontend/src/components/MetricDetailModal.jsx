import React, { useState, useEffect } from 'react';
import { X, History, Code, User, Tag, Calendar, Layers, Copy, Check } from 'lucide-react';
import StatusBadge from './StatusBadge';
import { getMetricVersionHistory } from '../api/api';

export const MetricDetailModal = ({ isOpen, onClose, metric }) => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (metric && isOpen) {
      fetchHistory();
    }
  }, [metric, isOpen]);

  const fetchHistory = async () => {
    try {
      setLoading(true);
      const data = await getMetricVersionHistory(metric.id);
      setHistory(data);
    } catch (err) {
      console.error('Error fetching version history:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !metric) return null;

  const handleCopySQL = () => {
    navigator.clipboard.writeText(metric.sql_formula);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '750px' }} onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ backgroundColor: '#E0F2FE', color: '#0EA5E9', padding: '8px', borderRadius: '8px' }}>
              <Layers size={20} />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
                  {metric.name}
                </h3>
                <StatusBadge status={metric.status} />
              </div>
              <span style={{ fontSize: '12px', color: '#64748B', fontFamily: 'Courier New, monospace' }}>
                Key: {metric.business_key} • Version {metric.version}
              </span>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}>
            <X size={20} />
          </button>
        </div>

        <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Metadata Badges */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
            <div style={{ backgroundColor: '#F8FAFC', padding: '10px 14px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
              <span style={{ fontSize: '11px', color: '#64748B', display: 'block' }}>Department</span>
              <strong style={{ fontSize: '13px', color: '#0F172A' }}>{metric.department}</strong>
            </div>
            <div style={{ backgroundColor: '#F8FAFC', padding: '10px 14px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
              <span style={{ fontSize: '11px', color: '#64748B', display: 'block' }}>Aggregation</span>
              <strong style={{ fontSize: '13px', color: '#0EA5E9' }}>{metric.aggregation_type}</strong>
            </div>
            <div style={{ backgroundColor: '#F8FAFC', padding: '10px 14px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
              <span style={{ fontSize: '11px', color: '#64748B', display: 'block' }}>Table</span>
              <strong style={{ fontSize: '13px', color: '#0F172A' }}>{metric.table_name || 'N/A'}</strong>
            </div>
            <div style={{ backgroundColor: '#F8FAFC', padding: '10px 14px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
              <span style={{ fontSize: '11px', color: '#64748B', display: 'block' }}>Owner</span>
              <strong style={{ fontSize: '12px', color: '#0F172A' }}>{metric.owner}</strong>
            </div>
          </div>

          {/* Definition */}
          <div>
            <h4 style={{ fontSize: '13px', fontWeight: 600, color: '#475569', marginBottom: '6px' }}>
              Business Definition
            </h4>
            <p style={{ fontSize: '14px', color: '#1E293B', backgroundColor: '#F8FAFC', padding: '12px 16px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
              {metric.definition}
            </p>
          </div>

          {/* Approved Formula */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
              <h4 style={{ fontSize: '13px', fontWeight: 600, color: '#475569', margin: 0 }}>
                Approved Standard SQL Formula
              </h4>
              <button 
                onClick={handleCopySQL}
                className="btn btn-secondary"
                style={{ padding: '4px 10px', fontSize: '12px' }}
              >
                {copied ? <Check size={14} color="#10B981" /> : <Copy size={14} />}
                {copied ? 'Copied' : 'Copy SQL'}
              </button>
            </div>
            <div className="code-block" style={{ backgroundColor: '#F0F9FF', borderColor: '#BAE6FD', color: '#0369A1' }}>
              {metric.sql_formula}
            </div>
          </div>

          {/* Filter condition */}
          {metric.filter_condition && (
            <div>
              <h4 style={{ fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                Standard Filter Condition
              </h4>
              <code style={{ fontSize: '12px', color: '#475569', backgroundColor: '#F1F5F9', padding: '4px 8px', borderRadius: '4px' }}>
                WHERE {metric.filter_condition}
              </code>
            </div>
          )}

          {/* Version History Audit Trail */}
          <div style={{ borderTop: '1px solid #E2E8F0', paddingTop: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <History size={16} color="#8B5CF6" />
              <h4 style={{ fontSize: '14px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
                Version Change History
              </h4>
            </div>

            {loading ? (
              <p style={{ fontSize: '13px', color: '#64748B' }}>Loading version history...</p>
            ) : history.length === 0 ? (
              <p style={{ fontSize: '13px', color: '#64748B' }}>No previous version changes recorded.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {history.map((ver, idx) => (
                  <div key={ver.id || idx} style={{
                    borderLeft: '2px solid #8B5CF6',
                    paddingLeft: '14px',
                    position: 'relative'
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{
                          backgroundColor: '#EDE9FE',
                          color: '#7C3AED',
                          padding: '2px 8px',
                          borderRadius: '4px',
                          fontSize: '11px',
                          fontWeight: 700
                        }}>
                          v{ver.version}
                        </span>
                        <strong style={{ fontSize: '13px', color: '#0F172A' }}>{ver.changed_by}</strong>
                      </div>
                      <span style={{ fontSize: '11px', color: '#94A3B8' }}>
                        {new Date(ver.timestamp).toLocaleString()}
                      </span>
                    </div>

                    <p style={{ fontSize: '12px', color: '#475569', marginTop: '4px', marginBottom: '6px' }}>
                      "{ver.change_reason}"
                    </p>

                    <div style={{
                      fontSize: '12px',
                      fontFamily: 'Courier New, monospace',
                      backgroundColor: '#F8FAFC',
                      padding: '6px 10px',
                      borderRadius: '4px',
                      color: '#0F172A'
                    }}>
                      {ver.previous_formula && (
                        <div style={{ textDecoration: 'line-through', color: '#EF4444', marginBottom: '2px' }}>
                          Old: {ver.previous_formula}
                        </div>
                      )}
                      <div style={{ color: '#10B981', fontWeight: 600 }}>
                        New: {ver.new_formula}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="modal-footer">
          <button onClick={onClose} className="btn btn-secondary">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default MetricDetailModal;
