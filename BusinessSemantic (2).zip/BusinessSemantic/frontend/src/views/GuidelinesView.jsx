import React from 'react';
import { BookOpen, ShieldCheck, CheckCircle2, AlertTriangle, Sparkles, Layers } from 'lucide-react';

export const GuidelinesView = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Banner */}
      <div className="card" style={{ backgroundColor: '#F0F9FF', borderColor: '#BAE6FD' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ backgroundColor: '#0EA5E9', color: '#FFFFFF', padding: '12px', borderRadius: '12px' }}>
            <BookOpen size={24} />
          </div>
          <div>
            <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#0369A1', margin: 0 }}>
              Business Intelligence Semantic Layer Guidelines
            </h3>
            <p style={{ fontSize: '13px', color: '#0284C7', margin: 0 }}>
              College Project Reference Guide: Standardizing Metric Logic Across Enterprise Analytics
            </p>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* Section 1: The Problem */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#EF4444' }}>
            <AlertTriangle size={20} />
            <h4 style={{ fontSize: '16px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
              The Metric Inconsistency Problem
            </h4>
          </div>
          <p style={{ fontSize: '13px', color: '#475569', lineHeight: '1.6' }}>
            In large organizations, different departments often calculate key metrics differently using raw SQL. 
            For example:
          </p>
          <div style={{ backgroundColor: '#FFF5F5', border: '1px solid #FECACA', borderRadius: '8px', padding: '12px', fontSize: '12.5px' }}>
            <strong style={{ color: '#DC2626', display: 'block', marginBottom: '4px' }}>Example Discrepancy:</strong>
            • <strong>Finance Department:</strong> Approved Revenue = <code>SUM(order_amount)</code><br/>
            • <strong>Sales Department:</strong> Submitted Revenue = <code>SUM(order_amount - discount)</code><br/>
            <span style={{ color: '#7F1D1D', display: 'block', marginTop: '6px' }}>
              Result: Two conflicting revenue numbers presented to executive board leadership!
            </span>
          </div>
        </div>

        {/* Section 2: The Solution */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#10B981' }}>
            <ShieldCheck size={20} />
            <h4 style={{ fontSize: '16px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
              How Semantic Layer Solves It
            </h4>
          </div>
          <p style={{ fontSize: '13px', color: '#475569', lineHeight: '1.6' }}>
            A Centralized BI Semantic Layer acts as a single source of truth between the underlying database and business dashboards.
          </p>
          <div style={{ backgroundColor: '#F0FDF4', border: '1px solid #A7F3D0', borderRadius: '8px', padding: '12px', fontSize: '12.5px' }}>
            <strong style={{ color: '#166534', display: 'block', marginBottom: '4px' }}>Core Capabilities of this Platform:</strong>
            1. <strong>Central Metric Repository:</strong> Enforces unique business keys and approved formulas.<br/>
            2. <strong>SQL Validation:</strong> Analyzes custom queries to flag formula drift.<br/>
            3. <strong>Automatic Recommendation:</strong> Provides ready-to-use standardized SQL snippets.<br/>
            4. <strong>Version History:</strong> Audits metric changes across versions (v1.0, v1.1).
          </div>
        </div>
      </div>

      {/* Standard Metrics Demonstration Reference */}
      <div className="card">
        <h4 style={{ fontSize: '16px', fontWeight: 600, color: '#0F172A', marginBottom: '14px' }}>
          Standardized Sample Metrics Reference Catalog
        </h4>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px' }}>
          <div style={{ backgroundColor: '#F8FAFC', border: '1px solid #E2E8F0', padding: '14px', borderRadius: '8px' }}>
            <strong style={{ fontSize: '14px', color: '#0F172A', display: 'block' }}>Revenue</strong>
            <span style={{ fontSize: '11px', color: '#0EA5E9', fontWeight: 600 }}>Finance</span>
            <code style={{ display: 'block', fontSize: '12px', marginTop: '6px', color: '#0F172A' }}>SUM(order_amount)</code>
          </div>

          <div style={{ backgroundColor: '#F8FAFC', border: '1px solid #E2E8F0', padding: '14px', borderRadius: '8px' }}>
            <strong style={{ fontSize: '14px', color: '#0F172A', display: 'block' }}>Profit Margin</strong>
            <span style={{ fontSize: '11px', color: '#0EA5E9', fontWeight: 600 }}>Executive</span>
            <code style={{ display: 'block', fontSize: '12px', marginTop: '6px', color: '#0F172A' }}>(SUM(revenue - cost)/SUM(revenue))*100</code>
          </div>

          <div style={{ backgroundColor: '#F8FAFC', border: '1px solid #E2E8F0', padding: '14px', borderRadius: '8px' }}>
            <strong style={{ fontSize: '14px', color: '#0F172A', display: 'block' }}>Customer Retention Rate</strong>
            <span style={{ fontSize: '11px', color: '#0EA5E9', fontWeight: 600 }}>Marketing</span>
            <code style={{ display: 'block', fontSize: '12px', marginTop: '6px', color: '#0F172A' }}>(COUNT(active)/COUNT(start))*100</code>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GuidelinesView;
