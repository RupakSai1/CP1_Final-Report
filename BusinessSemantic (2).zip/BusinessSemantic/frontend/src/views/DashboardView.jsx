import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Layers, 
  ArrowRight, 
  Code2, 
  ShieldCheck, 
  Activity,
  BarChart3
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';

export const DashboardView = ({ stats, setActiveTab, onValidateMetric }) => {
  if (!stats) return <div style={{ padding: '20px', color: '#64748B' }}>Loading Dashboard...</div>;

  const {
    total_metrics = 0,
    approved_metrics = 0,
    pending_metrics = 0,
    inconsistent_metrics = 0,
    department_distribution = {},
    recent_validations = []
  } = stats;

  const approvedPercent = total_metrics ? Math.round((approved_metrics / total_metrics) * 100) : 0;
  const pendingPercent = total_metrics ? Math.round((pending_metrics / total_metrics) * 100) : 0;
  const inconsistentPercent = total_metrics ? Math.round((inconsistent_metrics / total_metrics) * 100) : 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Overview KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
        {/* Total Metrics */}
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ backgroundColor: '#E0F2FE', color: '#0EA5E9', padding: '14px', borderRadius: '12px' }}>
            <Layers size={24} />
          </div>
          <div>
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
              Total Metrics
            </span>
            <h2 style={{ fontSize: '26px', fontWeight: 700, color: '#0F172A', margin: 0 }}>
              {total_metrics}
            </h2>
            <span style={{ fontSize: '12px', color: '#0EA5E9' }}>Registered in Semantic Layer</span>
          </div>
        </div>

        {/* Approved Metrics */}
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ backgroundColor: '#D1FAE5', color: '#10B981', padding: '14px', borderRadius: '12px' }}>
            <CheckCircle2 size={24} />
          </div>
          <div>
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
              Approved
            </span>
            <h2 style={{ fontSize: '26px', fontWeight: 700, color: '#0F172A', margin: 0 }}>
              {approved_metrics}
            </h2>
            <span style={{ fontSize: '12px', color: '#059669' }}>{approvedPercent}% Standardized</span>
          </div>
        </div>

        {/* Pending Review */}
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ backgroundColor: '#FFEDD5', color: '#F97316', padding: '14px', borderRadius: '12px' }}>
            <Clock size={24} />
          </div>
          <div>
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
              Pending Review
            </span>
            <h2 style={{ fontSize: '26px', fontWeight: 700, color: '#0F172A', margin: 0 }}>
              {pending_metrics}
            </h2>
            <span style={{ fontSize: '12px', color: '#EA580C' }}>{pendingPercent}% Awaiting Governance</span>
          </div>
        </div>

        {/* Inconsistent Metrics */}
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ backgroundColor: '#EDE9FE', color: '#8B5CF6', padding: '14px', borderRadius: '12px' }}>
            <AlertTriangle size={24} />
          </div>
          <div>
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
              Inconsistent
            </span>
            <h2 style={{ fontSize: '26px', fontWeight: 700, color: '#0F172A', margin: 0 }}>
              {inconsistent_metrics}
            </h2>
            <span style={{ fontSize: '12px', color: '#7C3AED' }}>{inconsistentPercent}% Drift Flagged</span>
          </div>
        </div>
      </div>

      {/* Main Grid Section */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '20px' }}>
        {/* Metric Health & Department Breakdown */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <h3 style={{ fontSize: '16px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
                Metric Standardization Status
              </h3>
              <p style={{ fontSize: '12px', color: '#64748B', margin: 0 }}>
                Overall consistency ratio across enterprise business units
              </p>
            </div>
            <button onClick={() => setActiveTab('consistency')} className="btn btn-secondary" style={{ fontSize: '12px' }}>
              Run Consistency Audit <ArrowRight size={14} />
            </button>
          </div>

          {/* Combined Progress Bar */}
          <div>
            <div style={{ display: 'flex', height: '12px', borderRadius: '6px', overflow: 'hidden', backgroundColor: '#F1F5F9' }}>
              <div style={{ width: `${approvedPercent}%`, backgroundColor: '#10B981' }} title={`Approved: ${approvedPercent}%`} />
              <div style={{ width: `${pendingPercent}%`, backgroundColor: '#F97316' }} title={`Pending: ${pendingPercent}%`} />
              <div style={{ width: `${inconsistentPercent}%`, backgroundColor: '#8B5CF6' }} title={`Inconsistent: ${inconsistentPercent}%`} />
            </div>
            <div style={{ display: 'flex', gap: '20px', marginTop: '10px', fontSize: '12px' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#059669' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#10B981' }} />
                Approved ({approved_metrics})
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#EA580C' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#F97316' }} />
                Pending ({pending_metrics})
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#7C3AED' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#8B5CF6' }} />
                Inconsistent ({inconsistent_metrics})
              </span>
            </div>
          </div>

          {/* Department Breakdown */}
          <div style={{ borderTop: '1px solid #E2E8F0', paddingTop: '16px' }}>
            <h4 style={{ fontSize: '14px', fontWeight: 600, color: '#0F172A', marginBottom: '12px' }}>
              Department Metric Distribution
            </h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
              {Object.entries(department_distribution).map(([dept, count]) => (
                <div key={dept} style={{
                  backgroundColor: '#F8FAFC',
                  border: '1px solid #E2E8F0',
                  borderRadius: '8px',
                  padding: '12px 14px'
                }}>
                  <div style={{ fontSize: '12px', color: '#64748B' }}>{dept}</div>
                  <div style={{ fontSize: '18px', fontWeight: 700, color: '#0F172A' }}>
                    {count} <span style={{ fontSize: '11px', fontWeight: 400, color: '#94A3B8' }}>metrics</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions & Validation Activity */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Quick Actions Card */}
          <div className="card" style={{ backgroundColor: '#F0F9FF', borderColor: '#BAE6FD' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: '#0369A1', marginBottom: '8px' }}>
              SQL Validation Engine
            </h3>
            <p style={{ fontSize: '12px', color: '#0284C7', marginBottom: '14px' }}>
              Compare analyst SQL queries against approved semantic layer definitions to catch calculation discrepancies.
            </p>
            <button 
              onClick={() => setActiveTab('validation')} 
              className="btn btn-primary"
              style={{ width: '100%', justifyContent: 'center' }}
            >
              <Code2 size={16} /> Open SQL Validator
            </button>
          </div>

          {/* Recent Validations Log */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Activity size={16} color="#0EA5E9" />
                <h4 style={{ fontSize: '14px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
                  Recent SQL Validations
                </h4>
              </div>
            </div>

            {recent_validations.length === 0 ? (
              <p style={{ fontSize: '12px', color: '#94A3B8' }}>No recent validations logged.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {recent_validations.map((log) => (
                  <div key={log.id} style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '8px 10px',
                    backgroundColor: '#F8FAFC',
                    borderRadius: '6px',
                    fontSize: '12px'
                  }}>
                    <div>
                      <strong style={{ color: '#0F172A' }}>{log.metric_name}</strong>
                      <div style={{ fontSize: '11px', color: '#94A3B8' }}>
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    <StatusBadge status={log.validation_status} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
