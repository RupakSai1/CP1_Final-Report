import React, { useState, useEffect } from 'react';
import { 
  Code2, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Copy, 
  Check, 
  Play, 
  ArrowRight,
  ShieldAlert,
  Terminal
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { validateSQLQuery } from '../api/api';

export const ValidationView = ({ metrics, initialMetric }) => {
  const [selectedMetricId, setSelectedMetricId] = useState('');
  const [submittedSQL, setSubmittedSQL] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (initialMetric) {
      setSelectedMetricId(initialMetric.id);
      setSubmittedSQL(`SELECT ${initialMetric.sql_formula} FROM ${initialMetric.table_name || 'orders'} WHERE ${initialMetric.filter_condition || '1=1'};`);
    } else if (metrics.length > 0 && !selectedMetricId) {
      const rev = metrics.find(m => m.business_key === 'revenue') || metrics[0];
      setSelectedMetricId(rev.id);
      // Set initial sample query with an deliberate inconsistency to showcase feature
      setSubmittedSQL(`SELECT SUM(order_amount - discount) FROM sales_orders WHERE order_status = 'completed';`);
    }
  }, [initialMetric, metrics]);

  const selectedMetric = metrics.find(m => m.id === Number(selectedMetricId)) || metrics[0];

  const handleMetricChange = (e) => {
    const id = Number(e.target.value);
    setSelectedMetricId(id);
    const m = metrics.find(item => item.id === id);
    if (m) {
      setSubmittedSQL(`SELECT ${m.sql_formula} FROM ${m.table_name || 'orders'} WHERE ${m.filter_condition || '1=1'};`);
    }
  };

  const handlePresetInconsistent = () => {
    if (!selectedMetric) return;
    if (selectedMetric.business_key === 'revenue') {
      setSubmittedSQL(`SELECT SUM(order_amount - discount) FROM sales_orders WHERE order_status = 'completed';`);
    } else if (selectedMetric.business_key === 'profit_margin') {
      setSubmittedSQL(`SELECT AVG(revenue - cost) FROM financial_ledger;`);
    } else {
      setSubmittedSQL(`SELECT AVG(amount) FROM ${selectedMetric.table_name || 'orders'};`);
    }
  };

  const handlePresetApproved = () => {
    if (!selectedMetric) return;
    setSubmittedSQL(`SELECT ${selectedMetric.sql_formula} FROM ${selectedMetric.table_name || 'orders'} WHERE ${selectedMetric.filter_condition || '1=1'};`);
  };

  const handleRunValidation = async () => {
    if (!submittedSQL.trim()) return;

    try {
      setLoading(true);
      const res = await validateSQLQuery({
        metric_id: selectedMetric ? selectedMetric.id : null,
        submitted_sql: submittedSQL
      });
      setResult(res);
    } catch (err) {
      console.error('Validation error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyRecommendation = () => {
    if (result && result.recommended_sql) {
      navigator.clipboard.writeText(result.recommended_sql);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Page Description */}
      <div className="card" style={{ backgroundColor: '#F0F9FF', borderColor: '#BAE6FD' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ backgroundColor: '#0EA5E9', color: '#FFFFFF', padding: '10px', borderRadius: '10px' }}>
            <Code2 size={22} />
          </div>
          <div>
            <h3 style={{ fontSize: '16px', fontWeight: 600, color: '#0369A1', margin: 0 }}>
              SQL Validation & Metric Consistency Engine
            </h3>
            <p style={{ fontSize: '13px', color: '#0284C7', margin: 0 }}>
              Validate submitted analyst queries against the governance semantic layer. Detect unapproved aggregations, missing discounts, or invalid column formulas.
            </p>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* Left Column: Validator Input Panel */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#475569', marginBottom: '6px' }}>
              Select Approved Semantic Layer Metric
            </label>
            <select 
              value={selectedMetricId} 
              onChange={handleMetricChange} 
              className="select-control"
              style={{ fontWeight: 600, color: '#0F172A' }}
            >
              {metrics.map(m => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.department}) — Approved: {m.sql_formula}
                </option>
              ))}
            </select>
          </div>

          {selectedMetric && (
            <div style={{ backgroundColor: '#F8FAFC', padding: '12px', borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px' }}>
              <div style={{ color: '#64748B', marginBottom: '4px' }}>Approved Metric Definition:</div>
              <strong style={{ color: '#0F172A', display: 'block', marginBottom: '6px' }}>
                {selectedMetric.definition}
              </strong>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ color: '#64748B' }}>Standard Formula:</span>
                <code style={{ color: '#0EA5E9', fontWeight: 700, fontFamily: 'Courier New, monospace' }}>
                  {selectedMetric.sql_formula}
                </code>
              </div>
            </div>
          )}

          {/* Quick Presets */}
          <div>
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#64748B', display: 'block', marginBottom: '6px' }}>
              Try Preset Test Examples:
            </span>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                type="button" 
                onClick={handlePresetInconsistent}
                className="btn btn-secondary"
                style={{ fontSize: '12px', color: '#EF4444', borderColor: '#FECACA' }}
              >
                Load Inconsistent Query
              </button>
              <button 
                type="button" 
                onClick={handlePresetApproved}
                className="btn btn-secondary"
                style={{ fontSize: '12px', color: '#10B981', borderColor: '#A7F3D0' }}
              >
                Load Approved Standard Query
              </button>
            </div>
          </div>

          {/* Textarea for submitted SQL */}
          <div>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#475569', marginBottom: '6px' }}>
              Submitted SQL Query / Formula
            </label>
            <textarea
              rows="6"
              value={submittedSQL}
              onChange={(e) => setSubmittedSQL(e.target.value)}
              className="textarea-control"
              style={{ fontFamily: 'Courier New, monospace', fontSize: '13px', backgroundColor: '#FAFAFA' }}
              placeholder="Paste SQL snippet to compare against semantic layer standard..."
            />
          </div>

          <button 
            onClick={handleRunValidation} 
            disabled={loading}
            className="btn btn-primary"
            style={{ width: '100%', justifyContent: 'center', height: '42px', fontSize: '14px' }}
          >
            <Play size={16} />
            {loading ? 'Running Validation Engine...' : 'Run SQL Validation Check'}
          </button>
        </div>

        {/* Right Column: Validation Result & Recommendation Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {!result ? (
            <div className="card" style={{ textAlign: 'center', padding: '48px 24px', color: '#94A3B8' }}>
              <Terminal size={40} style={{ marginBottom: '12px', opacity: 0.5 }} />
              <h4 style={{ fontSize: '15px', fontWeight: 600, color: '#475569', margin: 0 }}>
                Awaiting SQL Validation
              </h4>
              <p style={{ fontSize: '13px', margin: '4px 0 0 0' }}>
                Select a metric and click "Run SQL Validation Check" to analyze consistency.
              </p>
            </div>
          ) : (
            <>
              {/* Status Result Card */}
              <div className="card" style={{ 
                borderColor: result.is_consistent ? '#A7F3D0' : '#DDD6FE',
                backgroundColor: result.is_consistent ? '#F0FDF4' : '#F5F3FF'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    {result.is_consistent ? (
                      <CheckCircle2 size={24} color="#10B981" />
                    ) : (
                      <AlertTriangle size={24} color="#8B5CF6" />
                    )}
                    <div>
                      <h3 style={{ fontSize: '16px', fontWeight: 700, color: result.is_consistent ? '#166534' : '#5B21B6', margin: 0 }}>
                        {result.is_consistent ? 'APPROVED METRIC MATCH' : 'INCONSISTENT METRIC LOGIC'}
                      </h3>
                      <span style={{ fontSize: '12px', color: result.is_consistent ? '#15803D' : '#6D28D9' }}>
                        Validation target: {result.metric_name}
                      </span>
                    </div>
                  </div>
                  <StatusBadge status={result.validation_status} />
                </div>

                {/* Issues breakdown */}
                {result.issues_found && result.issues_found.length > 0 && (
                  <div style={{
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E2E8F0',
                    borderRadius: '8px',
                    padding: '12px',
                    marginTop: '8px'
                  }}>
                    <strong style={{ fontSize: '12px', color: '#7C3AED', display: 'block', marginBottom: '6px' }}>
                      Discrepancies Identified:
                    </strong>
                    <ul style={{ paddingLeft: '20px', margin: 0, fontSize: '12px', color: '#475569' }}>
                      {result.issues_found.map((issue, idx) => (
                        <li key={idx} style={{ marginBottom: '4px' }}>{issue}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Recommendation Module */}
              <div className="card" style={{ borderColor: '#BAE6FD' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Sparkles size={18} color="#0EA5E9" />
                    <h4 style={{ fontSize: '14px', fontWeight: 600, color: '#0369A1', margin: 0 }}>
                      Governance Recommendation
                    </h4>
                  </div>
                  <button 
                    onClick={handleCopyRecommendation}
                    className="btn btn-secondary"
                    style={{ padding: '4px 10px', fontSize: '12px' }}
                  >
                    {copied ? <Check size={14} color="#10B981" /> : <Copy size={14} />}
                    {copied ? 'Copied' : 'Copy Standard SQL'}
                  </button>
                </div>

                <p style={{ fontSize: '12px', color: '#475569', marginBottom: '10px' }}>
                  Use the standardized SQL query snippet below to ensure metric definition consistency across all reports and dashboards:
                </p>

                <div className="code-block" style={{ backgroundColor: '#F0F9FF', borderColor: '#BAE6FD', color: '#0369A1' }}>
                  {result.recommended_sql}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ValidationView;
