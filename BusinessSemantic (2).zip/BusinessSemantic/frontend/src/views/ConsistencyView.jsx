import React, { useState, useEffect } from 'react';
import { 
  GitCompare, 
  ShieldCheck, 
  AlertTriangle, 
  RefreshCw, 
  CheckCircle2, 
  Layers,
  ArrowUpRight,
  Info
} from 'lucide-react';
import { getConsistencyReport } from '../api/api';

export const ConsistencyView = () => {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchReport();
  }, []);

  const fetchReport = async () => {
    try {
      setLoading(true);
      const data = await getConsistencyReport();
      setReport(data);
    } catch (err) {
      console.error('Error fetching consistency report:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && !report) {
    return <div style={{ padding: '20px', color: '#64748B' }}>Running Consistency Audit Scan...</div>;
  }

  const {
    total_metrics_audited = 0,
    approved_count = 0,
    pending_count = 0,
    inconsistent_count = 0,
    health_score = 100,
    issues = []
  } = report || {};

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Header Banner */}
      <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ backgroundColor: '#EDE9FE', color: '#8B5CF6', padding: '12px', borderRadius: '12px' }}>
            <GitCompare size={24} />
          </div>
          <div>
            <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
              Repository Consistency Audit Scanner
            </h3>
            <p style={{ fontSize: '13px', color: '#64748B', margin: 0 }}>
              Automated detection of metric definition drift, duplicate keys, and conflicting formulas across enterprise departments.
            </p>
          </div>
        </div>

        <button onClick={fetchReport} disabled={loading} className="btn btn-primary">
          <RefreshCw size={16} className={loading ? 'spin' : ''} />
          {loading ? 'Scanning...' : 'Re-Run Consistency Audit'}
        </button>
      </div>

      {/* Governance Health & Metrics Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '20px' }}>
        {/* Governance Health Meter Card */}
        <div className="card" style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', padding: '24px' }}>
          <span style={{ fontSize: '12px', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
            Semantic Governance Health Score
          </span>
          <div style={{
            fontSize: '44px',
            fontWeight: 800,
            color: health_score >= 80 ? '#10B981' : (health_score >= 60 ? '#F97316' : '#EF4444'),
            margin: '12px 0 4px 0'
          }}>
            {health_score}%
          </div>
          <span style={{
            fontSize: '12px',
            backgroundColor: health_score >= 80 ? '#D1FAE5' : '#FFEDD5',
            color: health_score >= 80 ? '#059669' : '#EA580C',
            padding: '4px 12px',
            borderRadius: '20px',
            fontWeight: 600
          }}>
            {health_score >= 80 ? 'High Standard Compliance' : 'Attention Required'}
          </span>
        </div>

        {/* Audit Counters */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px' }}>
          <div className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <span style={{ fontSize: '12px', color: '#64748B' }}>Total Metrics Scanned</span>
            <h2 style={{ fontSize: '24px', fontWeight: 700, color: '#0F172A', margin: '4px 0' }}>
              {total_metrics_audited}
            </h2>
            <span style={{ fontSize: '11px', color: '#94A3B8' }}>Across all departments</span>
          </div>
          <div className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <span style={{ fontSize: '12px', color: '#64748B' }}>Verified Approved</span>
            <h2 style={{ fontSize: '24px', fontWeight: 700, color: '#10B981', margin: '4px 0' }}>
              {approved_count}
            </h2>
            <span style={{ fontSize: '11px', color: '#059669' }}>100% Consistent</span>
          </div>
          <div className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <span style={{ fontSize: '12px', color: '#64748B' }}>Flagged Inconsistent / Drift</span>
            <h2 style={{ fontSize: '24px', fontWeight: 700, color: '#8B5CF6', margin: '4px 0' }}>
              {inconsistent_count + issues.length}
            </h2>
            <span style={{ fontSize: '11px', color: '#7C3AED' }}>Action items identified</span>
          </div>
        </div>
      </div>

      {/* Issues & Conflicts Breakdown Matrix */}
      <div className="card">
        <h4 style={{ fontSize: '16px', fontWeight: 600, color: '#0F172A', marginBottom: '14px' }}>
          Metric Discrepancies & Conflict Audit Matrix
        </h4>

        {issues.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '32px', color: '#10B981' }}>
            <CheckCircle2 size={36} style={{ marginBottom: '8px' }} />
            <h4 style={{ fontSize: '16px', fontWeight: 600, margin: 0 }}>No Metric Inconsistencies Found!</h4>
            <p style={{ fontSize: '13px', color: '#64748B', margin: '4px 0 0 0' }}>
              All metric definitions in the repository comply with semantic layer standardization standards.
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {issues.map((issue, idx) => (
              <div key={idx} style={{
                border: '1px solid #E2E8F0',
                borderRadius: '8px',
                padding: '16px',
                backgroundColor: issue.severity === 'HIGH' ? '#FFF5F5' : '#F8FAFC',
                borderColor: issue.severity === 'HIGH' ? '#FECACA' : '#E2E8F0'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <AlertTriangle size={18} color={issue.severity === 'HIGH' ? '#EF4444' : '#F97316'} />
                    <strong style={{ fontSize: '14px', color: '#0F172A' }}>{issue.metric_name}</strong>
                    <code style={{ fontSize: '12px', color: '#64748B' }}>({issue.business_key})</code>
                  </div>
                  <span style={{
                    fontSize: '11px',
                    fontWeight: 700,
                    backgroundColor: issue.severity === 'HIGH' ? '#FEE2E2' : '#FFEDD5',
                    color: issue.severity === 'HIGH' ? '#DC2626' : '#EA580C',
                    padding: '2px 8px',
                    borderRadius: '4px'
                  }}>
                    {issue.severity} SEVERITY
                  </span>
                </div>

                <p style={{ fontSize: '13px', color: '#334155', marginBottom: '8px' }}>
                  {issue.description}
                </p>

                <div style={{
                  backgroundColor: '#FFFFFF',
                  padding: '8px 12px',
                  borderRadius: '6px',
                  fontSize: '12px',
                  border: '1px solid #E2E8F0',
                  color: '#0EA5E9'
                }}>
                  <strong>Governance Recommendation: </strong> {issue.recommendation}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ConsistencyView;
