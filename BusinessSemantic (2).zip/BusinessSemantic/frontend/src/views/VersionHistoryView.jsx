import React, { useState, useEffect } from 'react';
import { History, GitCommit, User, Calendar, Tag, ArrowRight } from 'lucide-react';
import { getMetrics } from '../api/api';

export const VersionHistoryView = ({ metrics }) => {
  // Aggregate version history entries across all metrics
  const allHistory = [];
  metrics.forEach(m => {
    if (m.history && m.history.length > 0) {
      m.history.forEach(h => {
        allHistory.push({
          ...h,
          metric_name: m.name,
          business_key: m.business_key,
          department: m.department
        });
      });
    }
  });

  // Sort by timestamp descending
  allHistory.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Banner */}
      <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{ backgroundColor: '#EDE9FE', color: '#8B5CF6', padding: '12px', borderRadius: '12px' }}>
          <History size={24} />
        </div>
        <div>
          <h3 style={{ fontSize: '18px', fontWeight: 600, color: '#0F172A', margin: 0 }}>
            Metric Version Audit Trail
          </h3>
          <p style={{ fontSize: '13px', color: '#64748B', margin: 0 }}>
            Complete historical audit trail of metric definition iterations, formula changes, and data steward notes.
          </p>
        </div>
      </div>

      {/* Audit Trail List */}
      <div className="card">
        <h4 style={{ fontSize: '15px', fontWeight: 600, color: '#0F172A', marginBottom: '16px' }}>
          Global Change Logs ({allHistory.length} Recorded Iterations)
        </h4>

        {allHistory.length === 0 ? (
          <p style={{ color: '#64748B', fontSize: '13px' }}>No version history recorded yet.</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {allHistory.map((item, idx) => (
              <div key={item.id || idx} style={{
                borderLeft: '3px solid #0EA5E9',
                backgroundColor: '#F8FAFC',
                borderRadius: '0 8px 8px 0',
                padding: '16px',
                border: '1px solid #E2E8F0',
                borderLeftWidth: '4px',
                borderLeftColor: '#0EA5E9'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <strong style={{ fontSize: '14px', color: '#0F172A' }}>{item.metric_name}</strong>
                    <span style={{ fontSize: '11px', color: '#64748B', fontFamily: 'Courier New, monospace' }}>
                      ({item.business_key})
                    </span>
                    <span style={{
                      fontSize: '11px',
                      fontWeight: 700,
                      backgroundColor: '#EDE9FE',
                      color: '#7C3AED',
                      padding: '2px 8px',
                      borderRadius: '4px'
                    }}>
                      v{item.version}
                    </span>
                  </div>
                  <span style={{ fontSize: '12px', color: '#94A3B8' }}>
                    {new Date(item.timestamp).toLocaleString()}
                  </span>
                </div>

                <p style={{ fontSize: '13px', color: '#475569', marginBottom: '10px' }}>
                  <strong style={{ color: '#0F172A' }}>Author:</strong> {item.changed_by} • <em>"{item.change_reason}"</em>
                </p>

                {/* Formula Comparison */}
                <div style={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid #E2E8F0',
                  borderRadius: '6px',
                  padding: '10px 14px',
                  fontFamily: 'Courier New, monospace',
                  fontSize: '12px'
                }}>
                  {item.previous_formula && (
                    <div style={{ textDecoration: 'line-through', color: '#EF4444', marginBottom: '4px' }}>
                      Previous: {item.previous_formula}
                    </div>
                  )}
                  <div style={{ color: '#059669', fontWeight: 600 }}>
                    Standardized: {item.new_formula}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VersionHistoryView;
