import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Eye, 
  Edit3, 
  Trash2, 
  Code2, 
  Layers, 
  CheckCircle, 
  Copy,
  Check
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';

export const RepositoryView = ({ 
  metrics, 
  onAddMetric, 
  onEditMetric, 
  onDeleteMetric, 
  onViewMetric, 
  onValidateMetric 
}) => {
  const [selectedDept, setSelectedDept] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [copiedId, setCopiedId] = useState(null);

  const departments = ['All', 'Finance', 'Sales', 'Marketing', 'Product', 'Customer Success'];
  const statuses = ['All', 'APPROVED', 'PENDING', 'INCONSISTENT', 'DEPRECATED'];
  const categories = ['All', 'Financial', 'Profitability', 'Retention', 'Sales Efficiency', 'Acquisition', 'Product Engagement'];

  const filteredMetrics = metrics.filter(m => {
    const matchDept = selectedDept === 'All' || m.department === selectedDept;
    const matchStatus = selectedStatus === 'All' || m.status === selectedStatus;
    const matchCategory = selectedCategory === 'All' || m.category === selectedCategory;
    return matchDept && matchStatus && matchCategory;
  });

  const handleCopyFormula = (id, formula) => {
    navigator.clipboard.writeText(formula);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Top Action Bar & Filters */}
      <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', color: '#64748B', fontWeight: 500 }}>
            <Filter size={16} /> Filters:
          </div>

          {/* Department Filter */}
          <select 
            value={selectedDept} 
            onChange={e => setSelectedDept(e.target.value)} 
            className="select-control"
            style={{ width: '150px', height: '36px', fontSize: '13px' }}
          >
            {departments.map(d => <option key={d} value={d}>Department: {d}</option>)}
          </select>

          {/* Status Filter */}
          <select 
            value={selectedStatus} 
            onChange={e => setSelectedStatus(e.target.value)} 
            className="select-control"
            style={{ width: '150px', height: '36px', fontSize: '13px' }}
          >
            {statuses.map(s => <option key={s} value={s}>Status: {s}</option>)}
          </select>

          {/* Category Filter */}
          <select 
            value={selectedCategory} 
            onChange={e => setSelectedCategory(e.target.value)} 
            className="select-control"
            style={{ width: '160px', height: '36px', fontSize: '13px' }}
          >
            {categories.map(c => <option key={c} value={c}>Category: {c}</option>)}
          </select>
        </div>

        <button onClick={onAddMetric} className="btn btn-primary">
          <Plus size={16} /> Add Business Metric
        </button>
      </div>

      {/* Metrics Table */}
      <div className="table-container">
        <table className="custom-table">
          <thead>
            <tr>
              <th>Metric Name & Key</th>
              <th>Department</th>
              <th>Category</th>
              <th>Standard SQL Formula</th>
              <th>Owner</th>
              <th>Version</th>
              <th>Status</th>
              <th style={{ textAlign: 'right' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredMetrics.length === 0 ? (
              <tr>
                <td colSpan="8" style={{ textAlign: 'center', padding: '32px', color: '#64748B' }}>
                  No metrics match the selected filter criteria.
                </td>
              </tr>
            ) : (
              filteredMetrics.map((metric) => (
                <tr key={metric.id}>
                  <td>
                    <div>
                      <strong style={{ fontSize: '14px', color: '#0F172A', display: 'block' }}>
                        {metric.name}
                      </strong>
                      <span style={{ fontSize: '11px', color: '#64748B', fontFamily: 'Courier New, monospace' }}>
                        {metric.business_key}
                      </span>
                    </div>
                  </td>
                  <td>
                    <span style={{
                      backgroundColor: '#F1F5F9',
                      color: '#334155',
                      padding: '2px 8px',
                      borderRadius: '4px',
                      fontSize: '12px',
                      fontWeight: 500
                    }}>
                      {metric.department}
                    </span>
                  </td>
                  <td>
                    <span style={{ fontSize: '12px', color: '#475569' }}>
                      {metric.category}
                    </span>
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <code style={{
                        fontSize: '12px',
                        backgroundColor: '#F0F9FF',
                        border: '1px solid #BAE6FD',
                        color: '#0284C7',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        maxWidth: '280px',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis'
                      }} title={metric.sql_formula}>
                        {metric.sql_formula}
                      </code>
                      <button
                        onClick={() => handleCopyFormula(metric.id, metric.sql_formula)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94A3B8' }}
                        title="Copy formula"
                      >
                        {copiedId === metric.id ? <Check size={14} color="#10B981" /> : <Copy size={14} />}
                      </button>
                    </div>
                  </td>
                  <td>
                    <span style={{ fontSize: '12px', color: '#475569' }}>
                      {metric.owner}
                    </span>
                  </td>
                  <td>
                    <span style={{
                      fontSize: '11px',
                      fontWeight: 700,
                      backgroundColor: '#EDE9FE',
                      color: '#7C3AED',
                      padding: '2px 6px',
                      borderRadius: '4px'
                    }}>
                      v{metric.version}
                    </span>
                  </td>
                  <td>
                    <StatusBadge status={metric.status} />
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                      <button
                        onClick={() => onViewMetric(metric)}
                        className="btn btn-secondary"
                        style={{ padding: '4px 8px', fontSize: '12px' }}
                        title="View Metadata & Version History"
                      >
                        <Eye size={14} />
                      </button>
                      <button
                        onClick={() => onValidateMetric(metric)}
                        className="btn btn-secondary"
                        style={{ padding: '4px 8px', fontSize: '12px', color: '#0EA5E9' }}
                        title="Test with SQL Validator"
                      >
                        <Code2 size={14} />
                      </button>
                      <button
                        onClick={() => onEditMetric(metric)}
                        className="btn btn-secondary"
                        style={{ padding: '4px 8px', fontSize: '12px' }}
                        title="Edit Metric"
                      >
                        <Edit3 size={14} />
                      </button>
                      <button
                        onClick={() => onDeleteMetric(metric.id)}
                        className="btn btn-danger"
                        style={{ padding: '4px 8px', fontSize: '12px' }}
                        title="Delete Metric"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RepositoryView;
