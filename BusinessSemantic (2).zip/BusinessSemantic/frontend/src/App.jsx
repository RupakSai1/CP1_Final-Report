import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MetricModal from './components/MetricModal';
import MetricDetailModal from './components/MetricDetailModal';

import DashboardView from './views/DashboardView';
import RepositoryView from './views/RepositoryView';
import ValidationView from './views/ValidationView';
import ConsistencyView from './views/ConsistencyView';
import VersionHistoryView from './views/VersionHistoryView';
import GuidelinesView from './views/GuidelinesView';

import { 
  getDashboardStats, 
  getMetrics, 
  createMetric, 
  updateMetric, 
  deleteMetric 
} from './api/api';

export function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [stats, setStats] = useState(null);
  const [metrics, setMetrics] = useState([]);
  const [loading, setLoading] = useState(true);

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [metricToEdit, setMetricToEdit] = useState(null);

  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [selectedMetricDetail, setSelectedMetricDetail] = useState(null);

  // Target metric passed to SQL Validation view
  const [validationTargetMetric, setValidationTargetMetric] = useState(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  useEffect(() => {
    fetchMetricsData();
  }, [searchTerm]);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const [statsData, metricsData] = await Promise.all([
        getDashboardStats(),
        getMetrics()
      ]);
      setStats(statsData);
      setMetrics(metricsData);
    } catch (err) {
      console.error('Failed to load initial data:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMetricsData = async () => {
    try {
      const data = await getMetrics({ search: searchTerm });
      setMetrics(data);
    } catch (err) {
      console.error('Failed to search metrics:', err);
    }
  };

  const refreshStats = async () => {
    try {
      const data = await getDashboardStats();
      setStats(data);
    } catch (err) {
      console.error('Error refreshing stats:', err);
    }
  };

  const handleOpenAddModal = () => {
    setMetricToEdit(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (metric) => {
    setMetricToEdit(metric);
    setIsModalOpen(true);
  };

  const handleSaveMetric = async (formData) => {
    try {
      if (metricToEdit) {
        await updateMetric(metricToEdit.id, formData);
      } else {
        await createMetric(formData);
      }
      setIsModalOpen(false);
      setMetricToEdit(null);
      fetchInitialData();
    } catch (err) {
      console.error('Failed to save metric:', err);
      alert(err.response?.data?.detail || 'Error saving metric');
    }
  };

  const handleDeleteMetric = async (id) => {
    if (!window.confirm('Are you sure you want to delete this metric definition?')) return;
    try {
      await deleteMetric(id);
      fetchInitialData();
    } catch (err) {
      console.error('Failed to delete metric:', err);
      alert('Error deleting metric');
    }
  };

  const handleViewMetric = (metric) => {
    setSelectedMetricDetail(metric);
    setIsDetailOpen(true);
  };

  const handleValidateMetric = (metric) => {
    setValidationTargetMetric(metric);
    setActiveTab('validation');
  };

  return (
    <div className="app-container">
      {/* Light Sidebar Navigation */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <div className="main-wrapper">
        {/* Top Header */}
        <Header 
          activeTab={activeTab} 
          searchTerm={searchTerm} 
          setSearchTerm={setSearchTerm} 
        />

        {/* View Routing */}
        <main className="content-body">
          {loading && !stats ? (
            <div style={{ padding: '40px', textAlign: 'center', color: '#64748B' }}>
              Connecting to BI Semantic Engine...
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && (
                <DashboardView 
                  stats={stats} 
                  setActiveTab={setActiveTab} 
                  onValidateMetric={handleValidateMetric}
                />
              )}

              {activeTab === 'repository' && (
                <RepositoryView 
                  metrics={metrics}
                  onAddMetric={handleOpenAddModal}
                  onEditMetric={handleOpenEditModal}
                  onDeleteMetric={handleDeleteMetric}
                  onViewMetric={handleViewMetric}
                  onValidateMetric={handleValidateMetric}
                />
              )}

              {activeTab === 'validation' && (
                <ValidationView 
                  metrics={metrics} 
                  initialMetric={validationTargetMetric} 
                />
              )}

              {activeTab === 'consistency' && (
                <ConsistencyView />
              )}

              {activeTab === 'history' && (
                <VersionHistoryView metrics={metrics} />
              )}

              {activeTab === 'guidelines' && (
                <GuidelinesView />
              )}
            </>
          )}
        </main>
      </div>

      {/* Create / Edit Modal */}
      <MetricModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveMetric}
        metricToEdit={metricToEdit}
      />

      {/* View Metric Details & Version History Modal */}
      <MetricDetailModal 
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        metric={selectedMetricDetail}
      />
    </div>
  );
}

export default App;
