import axios from 'axios';

const API_BASE_URL = 'http://127.0.0.1:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const getDashboardStats = async () => {
  const response = await api.get('/analytics/dashboard');
  return response.data;
};

export const getMetrics = async (params = {}) => {
  const response = await api.get('/metrics', { params });
  return response.data;
};

export const getMetricById = async (id) => {
  const response = await api.get(`/metrics/${id}`);
  return response.data;
};

export const createMetric = async (data) => {
  const response = await api.post('/metrics', data);
  return response.data;
};

export const updateMetric = async (id, data) => {
  const response = await api.put(`/metrics/${id}`, data);
  return response.data;
};

export const deleteMetric = async (id) => {
  const response = await api.delete(`/metrics/${id}`);
  return response.data;
};

export const getMetricVersionHistory = async (id) => {
  const response = await api.get(`/metrics/${id}/history`);
  return response.data;
};

export const validateSQLQuery = async (data) => {
  const response = await api.post('/validation', data);
  return response.data;
};

export const getValidationLogs = async () => {
  const response = await api.get('/validation/logs');
  return response.data;
};

export const getConsistencyReport = async () => {
  const response = await api.get('/consistency/report');
  return response.data;
};

export default api;
